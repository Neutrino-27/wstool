"""Visual theme: flat modern palette, ttk styles and a rounded button.

Tkinter cannot draw rounded corners on standard widgets, so: cards are flat with a
hairline border, and the action buttons are Canvas-drawn rounded rectangles.
Style option names are free-form in ttk (unknown ones are ignored), so a theme
mistake degrades the look but cannot crash the app.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk

FONT = "Segoe UI"
PALETTE = {
    "bg": "#f1f4f9", "card": "#ffffff", "border": "#dfe5ee", "text": "#1f2937", "muted": "#667085",
    "accent": "#2563eb", "accent_soft": "#dbe8ff", "status_bg": "#e6ebf3",
    "field_ro": "#f3f5f9", "trough": "#e4e9f1", "tab": "#e4e9f1",
}
# variant -> (fill, hover fill, text colour)
VARIANTS = {
    "primary": ("#2563eb", "#1d4ed8", "#ffffff"),
    "success": ("#16a34a", "#15803d", "#ffffff"),
    "secondary": ("#e8edf5", "#d9e1ee", "#1f2937"),
    "danger": ("#fde4e4", "#fbcaca", "#b42318"),
}
DISABLED = ("#eef1f5", "#eef1f5", "#a3acba")


def apply_theme(root) -> None:
    p = PALETTE
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    root.option_add("*Font", "{%s} 10" % FONT)
    style.configure(".", background=p["bg"], foreground=p["text"], font=(FONT, 10),
                    bordercolor=p["border"], troughcolor=p["trough"], focuscolor=p["bg"])
    style.configure("TFrame", background=p["bg"])
    style.configure("Card.TFrame", background=p["card"])
    style.configure("TLabel", background=p["bg"], foreground=p["text"])
    style.configure("Muted.TLabel", background=p["bg"], foreground=p["muted"], font=(FONT, 9))
    style.configure("Card.TLabel", background=p["card"], foreground=p["text"])
    style.configure("Muted.Card.TLabel", background=p["card"], foreground=p["muted"], font=(FONT, 9))
    style.configure("CardTitle.TLabel", background=p["card"], foreground=p["text"], font=(FONT, 11, "bold"))
    style.configure("State.Card.TLabel", background=p["card"], foreground=p["text"], font=(FONT, 10, "bold"))
    style.configure("Card.TCheckbutton", background=p["card"], foreground=p["text"], font=(FONT, 9))
    style.map("Card.TCheckbutton", background=[("active", p["card"])])

    style.configure("TEntry", padding=6, fieldbackground="#ffffff", foreground=p["text"],
                    bordercolor=p["border"], lightcolor=p["border"], darkcolor=p["border"], insertcolor=p["text"])
    style.map("TEntry",
              bordercolor=[("focus", p["accent"])], lightcolor=[("focus", p["accent"])],
              darkcolor=[("focus", p["accent"])],
              fieldbackground=[("readonly", p["field_ro"]), ("disabled", p["field_ro"])],
              foreground=[("disabled", p["muted"])])

    style.configure("TNotebook", background=p["bg"], borderwidth=0, tabmargins=(0, 0, 0, 0))
    style.configure("TNotebook.Tab", padding=(20, 9), font=(FONT, 10, "bold"), background=p["tab"],
                    foreground=p["muted"], borderwidth=0)
    style.map("TNotebook.Tab", background=[("selected", p["card"])], foreground=[("selected", p["accent"])])

    style.configure("Treeview", background=p["card"], fieldbackground=p["card"], foreground=p["text"],
                    rowheight=30, borderwidth=0, font=(FONT, 9))
    style.map("Treeview", background=[("selected", p["accent_soft"])], foreground=[("selected", p["text"])])
    style.configure("Treeview.Heading", background="#eef2f8", foreground=p["text"], relief="flat",
                    font=(FONT, 9, "bold"), padding=(8, 7), borderwidth=0)
    style.map("Treeview.Heading", background=[("active", "#e2e8f2")])

    style.configure("Accent.Horizontal.TProgressbar", troughcolor=p["trough"], background=p["accent"],
                    lightcolor=p["accent"], darkcolor=p["accent"], bordercolor=p["trough"], thickness=8)
    for orient in ("Vertical", "Horizontal"):
        name = "%s.TScrollbar" % orient
        style.configure(name, background="#c9d1de", troughcolor=p["card"], bordercolor=p["card"],
                        lightcolor="#c9d1de", darkcolor="#c9d1de", arrowcolor=p["muted"], relief="flat",
                        arrowsize=12, gripcount=0)
        style.map(name, background=[("active", "#aeb8c9")])


class RoundedButton(tk.Canvas):
    """Canvas-drawn rounded button with hover/press/disabled states.

    Supports the bits of the Button API the app uses: configure(state=, text=, command=),
    cget('state'), invoke(). `bg` must be the colour of the PARENT, so the corners blend in.
    """

    def __init__(self, master, text: str = "", command=None, variant: str = "secondary",
                 bg: str = PALETTE["card"], height: int = 36, width: int = 100, radius: int = 10,
                 font=None) -> None:
        super().__init__(master, height=height, width=width, bg=bg, highlightthickness=0, bd=0)
        self._text, self._command, self._variant = text, command, variant
        self._radius, self._font = radius, font or (FONT, 10, "bold")
        self._state, self._hover, self._pressed = "normal", False, False
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.after_idle(self._draw)

    # -- Button-like API ---------------------------------------------------------
    def configure(self, cnf=None, **kw):
        if "state" in kw:
            self._state = kw.pop("state")
            self._hover = self._pressed = False
        if "text" in kw:
            self._text = kw.pop("text")
        if "command" in kw:
            self._command = kw.pop("command")
        if cnf or kw:
            super().configure(cnf, **kw)
        self._draw()

    config = configure

    def cget(self, key):
        return self._state if key == "state" else super().cget(key)

    def invoke(self) -> None:
        if self._state == "normal" and self._command:
            self._command()

    # -- drawing -------------------------------------------------------------------
    def _colors(self):
        if self._state != "normal":
            return DISABLED
        fill, hover, fg = VARIANTS.get(self._variant, VARIANTS["secondary"])
        return (hover if (self._hover or self._pressed) else fill), hover, fg

    def _draw(self) -> None:
        w, h = self.winfo_width(), self.winfo_height()
        if w <= 1 or h <= 1:
            w, h = int(self.cget("width")), int(self.cget("height"))
        fill, _hover, fg = self._colors()
        r = min(self._radius, h // 2, w // 2)
        x1, y1, x2, y2 = 1, 1, w - 1, h - 1
        pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2,
               x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        self.delete("all")
        self.create_polygon(pts, smooth=True, fill=fill, outline=fill)
        self.create_text(w // 2, h // 2, text=self._text, fill=fg, font=self._font)
        self.configure_cursor()

    def configure_cursor(self) -> None:
        tk.Canvas.configure(self, cursor="hand2" if self._state == "normal" else "arrow")

    # -- events --------------------------------------------------------------------
    def _on_enter(self, _e=None) -> None:
        self._hover = True
        self._draw()

    def _on_leave(self, _e=None) -> None:
        self._hover = self._pressed = False
        self._draw()

    def _on_press(self, _e=None) -> None:
        if self._state == "normal":
            self._pressed = True
            self._draw()

    def _on_release(self, e) -> None:
        was_pressed, self._pressed = self._pressed, False
        self._draw()
        inside = 0 <= e.x <= max(self.winfo_width(), 1) and 0 <= e.y <= max(self.winfo_height(), 1)
        if was_pressed and inside and self._state == "normal" and self._command:
            self._command()
