"""Tkinter front end. Thin on purpose: widgets, layout and event wiring only.

Rules: the Tk thread never does network I/O (AppController does, on a worker
thread); worker threads never touch widgets (they emit UiEvents into a queue that
this module drains with `after`). All decisions live in controller/view_models.
"""
from __future__ import annotations

import queue
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox, ttk

from ..application.batch_runner import BatchRunner
from ..application.exporter import export_results_csv
from ..application.session_manager import SessionManager, SessionState
from ..application.transaction_service import TransactionService
from ..application.validators import build_params, collect_isns
from ..infrastructure.exceptions import SfcToolError, ValidationError
from ..infrastructure.logging_setup import setup_logging
from ..infrastructure.settings import Settings, load_settings
from ..integration.response_classifier import Outcome
from ..integration.soap_client import SoapClient
from ..operations.definitions import OPERATIONS
from . import view_models as vm
from .controller import AppController, UiEvent
from .theme import FONT, PALETTE, RoundedButton, apply_theme

MAX_CONSOLE_LINES = 5000
RESULT_COLUMNS = (("n", "#", 40), ("time", "Time", 70), ("isn", "ISN", 230), ("status", "Status", 80),
                  ("category", "Category", 130), ("review", "Review", 60), ("message", "Server message", 420),
                  ("ms", "ms", 55))
TAG_COLORS = {"accepted": "#e6f6ea", "rejected": "#fdeceb", "error": "#f8d3d0",
              "review": "#fff3c9", "skipped": "#eef0f4"}


class MainWindow:
    def __init__(self, root: tk.Tk, settings: Settings, session: SessionManager, runner: BatchRunner) -> None:
        self.root, self.settings = root, settings
        self._q: "queue.Queue[UiEvent]" = queue.Queue()
        self.ctl = AppController(session, runner, self._q.put)
        self.state = SessionState.DISCONNECTED
        self.busy = False
        self.batch_running = False
        self.closing = False
        self.current_op = None
        self.results: list = []
        self.last_summary = None
        self._after_id = None
        self._destroyed = False
        self._param_widgets: dict = {}

        apply_theme(root)
        root.title("SFC Testing Tool")
        root.geometry("1320x800")
        root.minsize(1100, 680)
        root.protocol("WM_DELETE_WINDOW", self._on_close)

        self.cred_vars = {k: tk.StringVar() for k in vm.CRED_FIELDS}
        self.cred_vars["TSP"].set("SFIS")
        self.keep_pw = tk.BooleanVar(value=False)
        self.single_isn = tk.StringVar()
        self.progress_text = tk.StringVar(value="")
        self.summary_text = tk.StringVar(value="No batch run yet.")
        self.status_text = tk.StringVar(value="Ready.")

        self._build()
        self._refresh_controls()
        self._set_state_label(SessionState.DISCONNECTED)
        self.log("info", "Ready. Fill the Session box and press Login. Environment: %s" % settings.environment)
        self._pump()

    # ------------------------------------------------------------------ layout
    def _build(self) -> None:
        self.root.configure(bg=PALETTE["bg"])
        # status bar first, so it always keeps its space
        tk.Label(self.root, textvariable=self.status_text, anchor="w", bg=PALETTE["status_bg"],
                 fg=PALETTE["muted"], padx=14, pady=7, font=(FONT, 9)).pack(fill=tk.X, side=tk.BOTTOM)
        main = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, sashrelief="flat", sashwidth=10,
                              bg=PALETTE["bg"], bd=0)
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        left, center, right = (ttk.Frame(main) for _ in range(3))
        main.add(left, width=350, minsize=300)
        main.add(center, width=410, minsize=340)
        main.add(right, minsize=450)
        self._build_session(left)
        self._build_operations(left)
        self._build_center(center)
        self._build_right(right)

    def _card(self, parent, title: str, *, expand: bool = False, pady=(0, 10)):
        """Flat white card with a hairline border. Returns (body frame, title label)."""
        outer = tk.Frame(parent, bg=PALETTE["card"], highlightbackground=PALETTE["border"],
                         highlightcolor=PALETTE["border"], highlightthickness=1, bd=0)
        outer.pack(fill=tk.BOTH if expand else tk.X, expand=expand, pady=pady)
        head = ttk.Label(outer, text=title, style="CardTitle.TLabel")
        head.pack(anchor="w", padx=16, pady=(14, 2))
        body = ttk.Frame(outer, style="Card.TFrame", padding=(16, 6, 16, 16))
        body.pack(fill=tk.BOTH, expand=True)
        return body, head

    def _build_session(self, parent) -> None:
        body, _ = self._card(parent, "Session")
        top = ttk.Frame(body, style="Card.TFrame")
        top.pack(fill=tk.X, pady=(0, 8))
        self.state_dot = tk.Label(top, text="\u25cf", font=(FONT, 16), bg=PALETTE["card"])
        self.state_dot.pack(side=tk.LEFT)
        self.state_label = ttk.Label(top, text="", style="State.Card.TLabel")
        self.state_label.pack(side=tk.LEFT, padx=6)
        grid = ttk.Frame(body, style="Card.TFrame")
        grid.pack(fill=tk.X)
        grid.columnconfigure(1, weight=1)
        self._cred_entries = []
        for i, name in enumerate(vm.CRED_FIELDS):
            ttk.Label(grid, text=name, style="Muted.Card.TLabel").grid(row=i, column=0, sticky="w", pady=4)
            ent = ttk.Entry(grid, textvariable=self.cred_vars[name], show="*" if "assword" in name else "")
            ent.grid(row=i, column=1, sticky="ew", padx=(10, 0), pady=4)
            self._cred_entries.append(ent)
        ttk.Checkbutton(body, text="Keep passwords in the form after login", variable=self.keep_pw,
                        style="Card.TCheckbutton").pack(anchor="w", pady=(8, 6))
        row = ttk.Frame(body, style="Card.TFrame")
        row.pack(fill=tk.X, pady=(4, 0))
        self.btn_check = RoundedButton(row, text="Check device", command=self._on_check, variant="secondary")
        self.btn_login = RoundedButton(row, text="Login", command=self._on_login, variant="primary")
        self.btn_logout = RoundedButton(row, text="Logout", command=self._on_logout, variant="secondary")
        for b in (self.btn_check, self.btn_login, self.btn_logout):
            b.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=3)

    def _build_operations(self, parent) -> None:
        body, _ = self._card(parent, "Operations / Methods", pady=(0, 0))
        self.op_list = tk.Listbox(body, exportselection=False, height=3, font=(FONT, 10), bg=PALETTE["card"],
                                  fg=PALETTE["text"], selectbackground=PALETTE["accent_soft"],
                                  selectforeground=PALETTE["text"], highlightthickness=0, relief="flat",
                                  bd=0, activestyle="none")
        self.op_list.pack(fill=tk.X)
        self._ops_by_index = list(OPERATIONS.values())
        for op in self._ops_by_index:
            self.op_list.insert(tk.END, "  " + op.label)
        self.op_list.bind("<<ListboxSelect>>", self._on_select_op)

    def _build_center(self, parent) -> None:
        body, self.params_title = self._card(parent, "Parameters (select an operation)")
        self.params_frame = ttk.Frame(body, style="Card.TFrame")
        self.params_frame.pack(fill=tk.X)
        self.params_frame.columnconfigure(1, weight=1)

        isn_body, _ = self._card(parent, "ISNs", expand=True)
        ttk.Label(isn_body, text="Single ISN", style="Muted.Card.TLabel").pack(anchor="w")
        ttk.Entry(isn_body, textvariable=self.single_isn).pack(fill=tk.X, pady=(2, 10))
        ttk.Label(isn_body, text="Batch list, one per line (used instead of the single ISN when filled)",
                  style="Muted.Card.TLabel").pack(anchor="w")
        holder = ttk.Frame(isn_body, style="Card.TFrame")
        holder.pack(fill=tk.BOTH, expand=True, pady=(2, 0))
        self.batch_text = tk.Text(holder, height=8, font=("Consolas", 10), wrap="none", undo=True, relief="flat",
                                  bd=0, padx=8, pady=6, highlightthickness=1,
                                  highlightbackground=PALETTE["border"], highlightcolor=PALETTE["accent"])
        sb = ttk.Scrollbar(holder, orient="vertical", command=self.batch_text.yview)
        self.batch_text.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.batch_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        run = ttk.Frame(parent)
        run.pack(fill=tk.X)
        self.btn_run = RoundedButton(run, text="RUN TRANSACTION / START BATCH", command=self._on_run,
                                     variant="success", bg=PALETTE["bg"], height=46, radius=14,
                                     font=(FONT, 11, "bold"))
        self.btn_run.pack(fill=tk.X)
        self.btn_cancel = RoundedButton(run, text="Cancel batch (stops after the current ISN)",
                                        command=self._on_cancel, variant="danger", bg=PALETTE["bg"], height=32)
        self.btn_cancel.pack(fill=tk.X, pady=(6, 0))
        self.progress = ttk.Progressbar(run, orient="horizontal", mode="determinate", maximum=1, value=0,
                                        style="Accent.Horizontal.TProgressbar")
        self.progress.pack(fill=tk.X, pady=(12, 0))
        ttk.Label(run, textvariable=self.progress_text, style="Muted.TLabel").pack(anchor="w", pady=(4, 0))

    def _build_right(self, parent) -> None:
        nb = ttk.Notebook(parent)
        nb.pack(fill=tk.BOTH, expand=True)
        res = ttk.Frame(nb, style="Card.TFrame", padding=12)
        con = ttk.Frame(nb, style="Card.TFrame", padding=12)
        nb.add(res, text="Results")
        nb.add(con, text="Console")

        bar = ttk.Frame(res, style="Card.TFrame")
        bar.pack(fill=tk.X, side=tk.BOTTOM, pady=(10, 0))
        ttk.Label(bar, textvariable=self.summary_text, style="Muted.Card.TLabel").pack(side=tk.LEFT)
        self.btn_export = RoundedButton(bar, text="Export CSV...", command=self._on_export,
                                        variant="secondary", width=130, height=32)
        self.btn_export.pack(side=tk.RIGHT)
        holder = ttk.Frame(res, style="Card.TFrame")
        holder.pack(fill=tk.BOTH, expand=True)
        cols = [c[0] for c in RESULT_COLUMNS]
        self.tree = ttk.Treeview(holder, columns=cols, show="headings", selectmode="browse")
        for key, title, width in RESULT_COLUMNS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w", stretch=(key == "message"))
        for tag, color in TAG_COLORS.items():
            self.tree.tag_configure(tag, background=color, foreground="#1f2937")
        ys = ttk.Scrollbar(holder, orient="vertical", command=self.tree.yview)
        xs = ttk.Scrollbar(holder, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side=tk.RIGHT, fill=tk.Y)
        xs.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)

        cbar = ttk.Frame(con, style="Card.TFrame")
        cbar.pack(fill=tk.X, side=tk.BOTTOM, pady=(10, 0))
        RoundedButton(cbar, text="Clear console", command=self._clear_console, variant="secondary",
                      width=130, height=32).pack(side=tk.RIGHT)
        cholder = ttk.Frame(con, style="Card.TFrame")
        cholder.pack(fill=tk.BOTH, expand=True)
        self.console = tk.Text(cholder, bg="#161a21", fg="#d7dde8", font=("Consolas", 10), wrap="word",
                               state="disabled", relief="flat", bd=0, padx=12, pady=10, highlightthickness=0,
                               insertbackground="#d7dde8")
        cs = ttk.Scrollbar(cholder, orient="vertical", command=self.console.yview)
        self.console.configure(yscrollcommand=cs.set)
        cs.pack(side=tk.RIGHT, fill=tk.Y)
        self.console.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        for tag, color in (("ok", "#7ee787"), ("err", "#ff7b72"), ("warn", "#e3b341"), ("info", "#d7dde8")):
            self.console.tag_configure(tag, foreground=color)

    # ------------------------------------------------------------- param form
    def _on_select_op(self, _event=None) -> None:
        sel = self.op_list.curselection()
        if not sel:
            return
        op = self._ops_by_index[sel[0]]
        self.current_op = op
        for w in self.params_frame.winfo_children():
            w.destroy()
        self._param_widgets.clear()
        self.params_title.configure(text="Parameters: %s" % op.method)
        row = 0
        for key in op.params:
            if key == "ISN":
                continue
            if key == "device":
                ttk.Label(self.params_frame, text="device (from Session)", style="Muted.Card.TLabel").grid(row=row, column=0, sticky="w", pady=4)
                ttk.Entry(self.params_frame, textvariable=self.cred_vars["device"], state="readonly").grid(
                    row=row, column=1, sticky="ew", padx=(10, 0), pady=4)
            else:
                ttk.Label(self.params_frame, text=key, style="Muted.Card.TLabel").grid(row=row, column=0, sticky="w", pady=4)
                default = op.defaults.get(key, "")
                if key == "data":
                    w = tk.Text(self.params_frame, height=3, width=24, font=("Consolas", 10), relief="flat", bd=0,
                                padx=6, pady=4, highlightthickness=1, highlightbackground=PALETTE["border"],
                                highlightcolor=PALETTE["accent"])
                    w.insert("1.0", default)
                else:
                    w = ttk.Entry(self.params_frame)
                    w.insert(0, default)
                w.grid(row=row, column=1, sticky="ew", padx=(10, 0), pady=4)
                self._param_widgets[key] = w
            row += 1
        self._refresh_controls()

    def _read_form(self) -> dict:
        values = {}
        for key, w in self._param_widgets.items():
            values[key] = w.get("1.0", "end-1c") if isinstance(w, tk.Text) else w.get()
        return values

    # ---------------------------------------------------------------- actions
    def _creds_or_warn(self):
        try:
            return vm.parse_credentials({k: v.get() for k, v in self.cred_vars.items()})
        except ValidationError as exc:
            messagebox.showwarning("Login data", str(exc))
            return None

    def _on_check(self) -> None:
        creds = None if self.state == SessionState.AUTHENTICATED else self._creds_or_warn()
        if self.state != SessionState.AUTHENTICATED and creds is None:
            return
        self.ctl.check_device(creds)

    def _on_login(self) -> None:
        creds = self._creds_or_warn()
        if creds is not None:
            self.status_text.set("Logging in...")
            self.ctl.login(creds)

    def _on_logout(self) -> None:
        self.ctl.logout()

    def _on_cancel(self) -> None:
        self.ctl.cancel_batch()
        self.log("warn", "Cancel requested: the batch stops after the current ISN.")

    def _on_run(self) -> None:
        op = self.current_op
        if op is None:
            messagebox.showinfo("Operation", "Select an operation first.")
            return
        isns = collect_isns(self.single_isn.get(), self.batch_text.get("1.0", "end-1c"))
        if isns.invalid:
            sample = "\n".join("line %d: %s (%s)" % (n, raw.strip(), why) for n, raw, why in isns.invalid[:8])
            if not messagebox.askyesno("Invalid ISNs", "%d line(s) will be skipped:\n\n%s\n\nContinue with the rest?"
                                       % (len(isns.invalid), sample), icon="warning", default="no"):
                return
        if not isns.isns:
            messagebox.showwarning("ISNs", "There are no valid ISNs to send.")
            return
        if isns.duplicates:
            self.log("warn", "%d duplicate ISN(s) dropped." % len(isns.duplicates))
        params = vm.collect_params(op, self._read_form(), self.ctl.device or "")
        try:
            build_params(op, params, isns.isns[0])                     # local validation before anything is sent
        except ValidationError as exc:
            messagebox.showerror("Parameters", str(exc))
            return
        if len(isns.isns) >= self.settings.confirm_batch_threshold:
            if not messagebox.askyesno("Confirm", "Send %d transactions to QA device %s?" % (len(isns.isns), params["device"]),
                                       default="no"):
                return
        self.ctl.run_batch(op, params, isns.isns)

    def _on_export(self) -> None:
        if not self.results:
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv", filetypes=[("CSV files", "*.csv")],
            initialfile="batch_%s.csv" % datetime.now().strftime("%Y%m%d_%H%M%S"))
        if not path:
            return
        try:
            n = export_results_csv(self.results, path)
            self.log("ok", "Exported %d rows to %s" % (n, path))
        except OSError as exc:
            messagebox.showerror("Export", "Could not write the file: %s" % exc)

    def _on_close(self) -> None:
        if self.closing:
            return
        if self.batch_running and not messagebox.askyesno(
                "Exit", "A batch is running. Cancel it, log out and exit?", icon="warning", default="no"):
            return
        self.closing = True
        self.status_text.set("Logging out and closing...")
        self.log("info", "Closing: logging out if needed...")
        self._refresh_controls()
        self.ctl.shutdown()
        self.root.after(15000, self._finish_close)     # never hang on a dead network

    def _finish_close(self) -> None:
        if self._destroyed:
            return
        self._destroyed = True
        if self._after_id is not None:
            try:
                self.root.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None
        self.ctl.dispose()
        self.root.destroy()

    # ------------------------------------------------------------ event pump
    def _pump(self) -> None:
        for _ in range(300):
            try:
                ev = self._q.get_nowait()
            except queue.Empty:
                break
            self._handle(ev)
            if self._destroyed:
                return
        self._after_id = self.root.after(80, self._pump)

    def _handle(self, ev: UiEvent) -> None:
        handler = getattr(self, "_ev_" + ev.kind, None)
        if handler is not None:
            handler(ev.data)

    def _ev_busy(self, busy: bool) -> None:
        self.busy = busy
        if not busy:
            self.batch_running = False
        self._refresh_controls()

    def _ev_session_state(self, state: SessionState) -> None:
        self.state = state
        self._set_state_label(state)
        if state == SessionState.AUTHENTICATED and not self.keep_pw.get():
            self.cred_vars["programPassword"].set("")
            self.cred_vars["password"].set("")
        if state == SessionState.SESSION_EXPIRED:
            self.log("err", "Session expired or lost. Log out and log in again.")
        self._refresh_controls()

    def _ev_log(self, data) -> None:
        self.log(*data)

    def _ev_device_check(self, c) -> None:
        if c.outcome == Outcome.DEVICE_FREE:
            self.log("ok", "Device check: free (not in use).")
        elif c.outcome == Outcome.DEVICE_IN_USE:
            who = c.detail.get("operator", "?")
            mine = " (your operator ID)" if c.detail.get("same_operator") else " (ANOTHER operator)"
            self.log("warn", "Device check: IN USE by %s%s since %s." % (who, mine, c.detail.get("since", "?")))
        else:
            self.log("err", "Device check: %s | %s" % (c.outcome.value, c.message))

    def _ev_login_result(self, c) -> None:
        if c.outcome == Outcome.LOGIN_OK:
            self.log("ok", "Login OK: %s" % " ".join(c.message.split()))
            self.status_text.set("Authenticated on device %s." % self.ctl.device)
        elif c.outcome == Outcome.ALREADY_LOGGED_IN:
            self.log("warn", "Login Twice: the device already has a session.")
        else:
            self.log("err", "%s | %s" % (c.outcome.value, " ".join(c.message.split())))
            self.status_text.set("Login failed: %s" % c.outcome.value)

    def _ev_login_conflict(self, data) -> None:
        creds_device = self.cred_vars["device"].get().strip()
        text, same = vm.conflict_message(data.get("check"), creds_device)
        answer = messagebox.askyesno("Device already logged in", text, icon="warning", default="no")
        self.ctl.resolve_conflict(answer)

    def _ev_logout_result(self, c) -> None:
        tag = "ok" if c.outcome == Outcome.LOGOUT_OK else "err"
        self.log(tag, "Logout: %s | %s" % (c.outcome.value, " ".join(c.message.split())))
        self.status_text.set("Logged out." if tag == "ok" else "Logout failed: the session is still open.")

    def _ev_batch_started(self, total: int) -> None:
        self.batch_running = True
        self.results = []
        self.last_summary = None
        self.tree.delete(*self.tree.get_children())
        self.progress.configure(maximum=max(total, 1), value=0)
        self.progress_text.set("0 / %d" % total)
        self.summary_text.set("Running...")
        self.status_text.set("Batch running (%d ISN)..." % total)
        self.log("info", "Batch started: %d ISN." % total)
        self._refresh_controls()

    def _ev_progress(self, data) -> None:
        done, total, res = data
        self.results.append(res)
        item = self.tree.insert("", "end", values=vm.result_row(done, res), tags=(vm.tag_for(res),))
        self.tree.see(item)
        self.progress.configure(value=done)
        self.progress_text.set("%d / %d" % (done, total))
        if res.uncertain:
            self.log("warn", "%s: outcome UNCERTAIN (%s). Check it manually before retrying." % (res.isn, res.category.value))

    def _ev_batch_done(self, summary) -> None:
        self.last_summary = summary
        self.batch_running = False
        line = vm.summary_line(summary)
        self.summary_text.set(line)
        self.status_text.set("Batch finished.")
        tag = "ok" if summary.all_accepted else "warn"
        self.log(tag, "Batch finished: " + line)
        self._refresh_controls()

    def _ev_error(self, message: str) -> None:
        self.log("err", message)
        self.status_text.set(message)
        messagebox.showerror("SFC Testing Tool", message)

    def _ev_closed(self, _data=None) -> None:
        self._finish_close()

    # --------------------------------------------------------------- helpers
    def _set_state_label(self, state: SessionState) -> None:
        self.state_dot.configure(fg=vm.SESSION_COLORS[state])
        text = vm.SESSION_LABELS[state]
        if state == SessionState.AUTHENTICATED and self.ctl.device:
            text += " (device %s)" % self.ctl.device
        self.state_label.configure(text=text)

    @staticmethod
    def _enable(widget, flag: bool) -> None:
        widget.configure(state="normal" if flag else "disabled")

    def _refresh_controls(self) -> None:
        st, busy, closing = self.state, self.busy, self.closing
        free = not busy and not closing
        disc = st == SessionState.DISCONNECTED
        auth = st == SessionState.AUTHENTICATED
        self._enable(self.btn_login, free and disc)
        self._enable(self.btn_check, free and (disc or auth))
        self._enable(self.btn_logout, free and st in (SessionState.AUTHENTICATED, SessionState.SESSION_EXPIRED))
        self._enable(self.btn_run, free and auth and self.current_op is not None)
        self._enable(self.btn_cancel, self.batch_running and not closing)
        self._enable(self.btn_export, free and bool(self.results))
        for ent in self._cred_entries:
            self._enable(ent, free and disc)

    def log(self, tag: str, text: str) -> None:
        self.console.configure(state="normal")
        self.console.insert("end", "[%s] %s\n" % (datetime.now().strftime("%H:%M:%S"), text), tag)
        lines = int(self.console.index("end-1c").split(".")[0])
        if lines > MAX_CONSOLE_LINES:
            self.console.delete("1.0", "%d.0" % (lines - MAX_CONSOLE_LINES))
        self.console.see("end")
        self.console.configure(state="disabled")

    def _clear_console(self) -> None:
        self.console.configure(state="normal")
        self.console.delete("1.0", "end")
        self.console.configure(state="disabled")


def main() -> int:
    try:  # sharp text on Windows high-DPI screens
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    root.withdraw()
    try:
        settings = load_settings()
        setup_logging(settings.log_dir, settings.log_level)
        client = SoapClient(settings)            # runs the QA environment guard
    except SfcToolError as exc:
        messagebox.showerror("SFC Testing Tool: cannot start", str(exc))
        root.destroy()
        return 1
    session = SessionManager(client, settings)
    runner = BatchRunner(TransactionService(session))
    root.deiconify()
    MainWindow(root, settings, session, runner)
    root.mainloop()
    return 0
