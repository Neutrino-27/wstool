@echo off
cd /d "%~dp0"
set PYTHONPATH=src
python -m sfc_tool
if errorlevel 1 pause
