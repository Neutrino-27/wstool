"""Headless smoke test of the Tk layer using a fake tkinter (see fake_tk.py)."""
import importlib
import sys
import time
import unittest

from tests.unit import fake_tk
from sfc_tool.application.batch_runner import BatchRunner
from sfc_tool.application.session_manager import SessionManager, SessionState as S
from sfc_tool.application.transaction_service import TransactionService
from tests.fixtures import sanitized_responses as F
from .helpers import SETTINGS
from .test_session_manager import FakeClient


class GuiSmoke(unittest.TestCase):
    def setUp(self):
        self._saved = {k: sys.modules.get(k) for k in ("tkinter", "tkinter.ttk", "tkinter.messagebox",
                                                       "tkinter.filedialog", "sfc_tool.presentation.app",
                                                       "sfc_tool.presentation.theme")}
        self.tk, self.mb, self.fd = fake_tk.install()
        sys.modules.pop("sfc_tool.presentation.app", None)
        sys.modules.pop("sfc_tool.presentation.theme", None)
        self.app = importlib.import_module("sfc_tool.presentation.app")
        self.addCleanup(self._restore)

    def _restore(self):
        for k, v in self._saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v

    def make(self, *script):
        self.client = FakeClient(*script)
        session = SessionManager(self.client, SETTINGS)
        self.root = self.tk.Tk()
        self.win = self.app.MainWindow(self.root, SETTINGS, session, BatchRunner(TransactionService(session)))
        self.addCleanup(self.win.ctl.dispose)
        return self.win

    def drain(self, cond, timeout=3.0):
        end = time.time() + timeout
        while time.time() < end:
            self.win._pump()
            if cond():
                return
            time.sleep(0.005)
        self.fail("condition not reached; console=%r" % self.win.console.text)

    def fill_login(self):
        for k, v in dict(programId="PID", programPassword="PW1", op="XXXX", password="PW2", device="310010").items():
            self.win.cred_vars[k].set(v)

    def login(self):
        self.fill_login(); self.win._on_login()
        self.drain(lambda: self.win.state == S.AUTHENTICATED and not self.win.busy)

    def select_op(self, i=0):
        self.win.op_list.sel = (i,); self.win._on_select_op()

    def test_initial_state_disables_actions(self):
        w = self.make()
        self.assertEqual((w.btn_login.cget("state"), w.btn_logout.cget("state"), w.btn_run.cget("state"),
                          w.btn_export.cget("state")), ("normal", "disabled", "disabled", "disabled"))
        self.assertEqual(len(w.op_list.items), 2)

    def test_missing_login_fields_warn_and_send_nothing(self):
        w = self.make()
        w._on_login()
        self.assertEqual(self.mb.calls[0][0], "showwarning")
        self.assertEqual(self.client.calls, [])

    def test_login_flow_updates_controls_and_clears_passwords(self):
        w = self.make(F.LIVE_LOGIN_OK)
        self.login()
        self.assertEqual((w.cred_vars["programPassword"].get(), w.cred_vars["password"].get()), ("", ""))
        self.assertEqual((w.btn_login.cget("state"), w.btn_logout.cget("state")), ("disabled", "normal"))
        self.assertIn("Login OK", w.console.text)
        self.assertEqual(w.state_label.kw["text"], "Authenticated (device 310010)")

    def test_keep_passwords_checkbox(self):
        w = self.make(F.LIVE_LOGIN_OK)
        w.keep_pw.set(True)
        self.login()
        self.assertEqual(w.cred_vars["password"].get(), "PW2")

    def test_parameter_form_defaults(self):
        w = self.make()
        self.select_op(1)                                   # MASSDATA
        pw = w._param_widgets
        self.assertEqual((pw["error"].get(), pw["status"].get(), pw["TSP"].get(), pw["aoiloc"].get()),
                         ("", "8", "SFIS", "TEST_LOC"))
        self.assertEqual(pw["data"].get(), "TEST")
        self.assertNotIn("device", pw)                      # device comes from the Session box
        self.assertEqual(len(pw), 13)

    def test_full_batch_fills_results_and_enables_export(self):
        w = self.make(F.LIVE_LOGIN_OK, F.RESULT_OK, F.RESULT_BAD_ISN)
        self.login(); self.select_op(0)
        w.batch_text.insert("1.0", "A1\nB2\n")
        w._on_run()
        self.drain(lambda: len(w.results) == 2 and not w.busy)
        self.assertEqual(len(w.tree.rows), 2)
        self.assertEqual(w.tree.rows[1]["tags"], ("rejected",))
        self.assertIn("2 ISN", w.summary_text.get())
        self.assertEqual(w.btn_export.cget("state"), "normal")
        sent = dict(self.client.calls[1][1])
        self.assertEqual((sent["ISN"], sent["error"], sent["device"]), ("A1", "", "310010"))

    def test_invalid_isn_lines_can_be_declined(self):
        w = self.make(F.LIVE_LOGIN_OK)
        self.login(); self.select_op(0)
        w.batch_text.insert("1.0", "BAD ISN\n")
        self.mb.answer = False
        w._on_run()
        self.assertEqual(len(self.client.calls), 1)         # only the login

    def test_login_twice_dialog_declined_sends_no_logout(self):
        w = self.make(F.LIVE_LOGIN_TWICE, F.LIVE_CHECK_IN_USE)
        self.mb.answer = False
        self.fill_login(); w._on_login()
        self.drain(lambda: any(c[0] == "askyesno" for c in self.mb.calls) and not w.busy)
        self.assertEqual(self.client.statuses(), ["1", "5"])
        self.assertEqual(w.state, S.DISCONNECTED)
        self.assertIn("YOUR OWN", self.mb.calls[0][1][1])

    def test_login_twice_dialog_accepted_recovers(self):
        w = self.make(F.LIVE_LOGIN_TWICE, F.LIVE_CHECK_IN_USE, F.LIVE_LOGOUT_OK, F.LIVE_LOGIN_OK)
        self.mb.answer = True
        self.fill_login(); w._on_login()
        self.drain(lambda: w.state == S.AUTHENTICATED and not w.busy)
        self.assertEqual(self.client.statuses(), ["1", "5", "2", "1"])

    def test_logout_button(self):
        w = self.make(F.LIVE_LOGIN_OK, F.LIVE_LOGOUT_OK)
        self.login(); w._on_logout()
        self.drain(lambda: w.state == S.DISCONNECTED and not w.busy)
        self.assertIn("Logout: LOGOUT_OK", w.console.text)

    def test_error_event_shows_dialog(self):
        w = self.make()
        w.ctl._emit(self.app.UiEvent("error", "boom message"))
        self.drain(lambda: any(c[0] == "showerror" for c in self.mb.calls))

    def test_close_logs_out_then_destroys(self):
        w = self.make(F.LIVE_LOGIN_OK, F.LIVE_LOGOUT_OK)
        self.login()
        w._on_close()
        self.drain(lambda: self.root.destroyed)
        self.assertEqual(self.client.statuses(), ["1", "2"])

    def test_close_when_disconnected(self):
        w = self.make()
        w._on_close()
        self.drain(lambda: self.root.destroyed)

    def test_export_writes_csv(self):
        import os, tempfile
        w = self.make(F.LIVE_LOGIN_OK, F.RESULT_OK)
        self.login(); self.select_op(0)
        w.single_isn.set("ONE"); w._on_run()
        self.drain(lambda: len(w.results) == 1 and not w.busy)
        path = os.path.join(tempfile.mkdtemp(), "o.csv")
        self.fd.answer = path
        w._on_export()
        with open(path, encoding="utf-8-sig") as fh:
            self.assertIn("ONE", fh.read())


class RoundedButtonTests(unittest.TestCase):
    def setUp(self):
        self._saved = {k: sys.modules.get(k) for k in ("tkinter", "tkinter.ttk", "tkinter.messagebox",
                                                       "tkinter.filedialog", "sfc_tool.presentation.theme")}
        self.tk, _, _ = fake_tk.install()
        sys.modules.pop("sfc_tool.presentation.theme", None)
        self.theme = importlib.import_module("sfc_tool.presentation.theme")
        self.addCleanup(self._restore)
        self.root = self.tk.Tk()

    def _restore(self):
        for k, v in self._saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v

    def click(self, btn):
        ev = type("E", (), {"x": 5, "y": 5})()
        btn._on_press(ev); btn._on_release(ev)

    def test_click_runs_command_once(self):
        hits = []
        b = self.theme.RoundedButton(self.root, text="Go", command=lambda: hits.append(1), variant="primary")
        self.click(b)
        self.assertEqual(hits, [1])

    def test_disabled_blocks_click_and_reports_state(self):
        hits = []
        b = self.theme.RoundedButton(self.root, text="Go", command=lambda: hits.append(1))
        b.configure(state="disabled")
        self.click(b); b.invoke()
        self.assertEqual((hits, b.cget("state")), ([], "disabled"))
        b.configure(state="normal"); self.click(b)
        self.assertEqual(hits, [1])

    def test_release_outside_does_not_fire(self):
        hits = []
        b = self.theme.RoundedButton(self.root, text="Go", command=lambda: hits.append(1))
        b._on_press(None); b._on_release(type("E", (), {"x": 500, "y": 5})())
        self.assertEqual(hits, [])

    def test_configure_text_command_and_all_variants_draw(self):
        b = self.theme.RoundedButton(self.root, text="A", variant="nonexistent")
        for v in list(self.theme.VARIANTS) + ["nonexistent"]:
            b._variant = v
            for st in ("normal", "disabled"):
                b.configure(state=st); b._on_enter(); b._on_leave(); b._draw()
        hits = []
        b.configure(state="normal", text="B", command=lambda: hits.append(1))
        self.click(b)
        self.assertEqual((b._text, hits), ("B", [1]))

    def test_apply_theme_runs(self):
        self.theme.apply_theme(self.root)


if __name__ == "__main__":
    unittest.main()
