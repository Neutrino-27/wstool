"""Minimal fake of tkinter/ttk/messagebox/filedialog for headless smoke tests.

It cannot validate real Tk option names; it catches Python-level mistakes
(NameError, wrong attribute use, bad event wiring) in the GUI layer.
"""
import sys
import types


class Var:
    def __init__(self, master=None, value=None, **kw):
        self._v = "" if value is None else value
    def get(self): return self._v
    def set(self, v): self._v = v
    def trace_add(self, *a, **k): pass


class Widget:
    def __init__(self, master=None, **kw):
        self.master, self.kw, self.children = master, dict(kw), []
        if isinstance(master, Widget):
            master.children.append(self)
    def __getattr__(self, name):               # pack/grid/bind/add/heading/... are no-ops
        if name.startswith("__"):
            raise AttributeError(name)
        return lambda *a, **k: None
    def configure(self, cnf=None, **kw): self.kw.update(kw)
    config = configure
    def cget(self, k): return self.kw.get(k)
    def winfo_children(self): return list(self.children)
    def destroy(self):
        if isinstance(self.master, Widget) and self in self.master.children:
            self.master.children.remove(self)
    def after(self, ms, fn=None, *a): return "after#1"


class Canvas(Widget):
    def winfo_width(self): return 100
    def winfo_height(self): return 36


class Style:
    def __init__(self, master=None): pass
    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return lambda *a, **k: None


class Entry(Widget):
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw); self.text = ""
    def insert(self, idx, s): self.text += s
    def delete(self, a, b=None): self.text = ""
    def get(self):
        var = self.kw.get("textvariable")
        return var.get() if var is not None else self.text


class Text(Widget):
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw); self.text = ""
    def insert(self, idx, s, *tags): self.text += s
    def delete(self, a, b=None): self.text = ""
    def get(self, a="1.0", b="end-1c"): return self.text
    def index(self, i): return "%d.0" % (self.text.count("\n") + 1)


class Listbox(Widget):
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw); self.items, self.sel = [], ()
    def insert(self, idx, s): self.items.append(s)
    def curselection(self): return self.sel


class Treeview(Widget):
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw); self.rows = []
    def insert(self, parent, index, **kw):
        self.rows.append(kw); return "I%d" % len(self.rows)
    def get_children(self): return tuple("I%d" % (i + 1) for i in range(len(self.rows)))
    def delete(self, *ids): self.rows = []


class Root(Widget):
    def __init__(self):
        super().__init__(None); self.destroyed = False
    def destroy(self): self.destroyed = True


class Box:
    """Recorder for messagebox / filedialog."""
    def __init__(self): self.calls, self.answer = [], True
    def _rec(self, name):
        def f(*a, **k):
            self.calls.append((name, a, k)); return self.answer
        return f
    def __getattr__(self, name):
        return self._rec(name)


def install():
    """Return (tk, messagebox, filedialog) fakes and register them in sys.modules."""
    tk = types.ModuleType("tkinter")
    for n in ("Tk", "Frame", "Label", "Button", "PanedWindow"):
        setattr(tk, n, type(n, (Widget,), {}))
    tk.Tk = Root
    tk.Canvas = Canvas
    tk.TclError = type("TclError", (Exception,), {})
    tk.Text, tk.Listbox = Text, Listbox
    tk.StringVar, tk.BooleanVar = Var, Var
    for n in ("HORIZONTAL", "RAISED", "BOTH", "X", "Y", "LEFT", "RIGHT", "BOTTOM", "END"):
        setattr(tk, n, n.lower())
    ttk = types.ModuleType("tkinter.ttk")
    for n in ("Frame", "LabelFrame", "Label", "Checkbutton", "Button", "Scrollbar", "Notebook", "Progressbar"):
        setattr(ttk, n, type(n, (Widget,), {}))
    ttk.Entry, ttk.Treeview, ttk.Style = Entry, Treeview, Style
    mb, fd = Box(), Box()
    tk.ttk, tk.messagebox, tk.filedialog = ttk, mb, fd
    sys.modules.update({"tkinter": tk, "tkinter.ttk": ttk, "tkinter.messagebox": mb, "tkinter.filedialog": fd})
    return tk, mb, fd
