"""Interpret the text inside <...Result> returned by the SFIS web service.

Observed wire format (live service): fields separated by the control character
0x7F: p_ret DEL p_msg DEL p_name [...]. If no separator is present (e.g. text that
lost control characters when copied), the first character is taken as p_ret and
the rest as p_msg. p_ret ('1' = OK, '0' = failure) is the success signal for
login, logout and transactions. Message text categorizes failures. The status=5
device check is decided by its MESSAGE: the live service returned p_ret=0 for an
"IN USED" answer, contradicting the documentation.
Anything unrecognized becomes Outcome.UNKNOWN and is never treated as success.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable, Optional


class Outcome(str, Enum):
    LOGIN_OK = "LOGIN_OK"
    ALREADY_LOGGED_IN = "ALREADY_LOGGED_IN"
    USER_NOT_FOUND = "USER_NOT_FOUND"
    DEVICE_NOT_DEFINED = "DEVICE_NOT_DEFINED"
    LOGIN_FAILED = "LOGIN_FAILED"
    LOGOUT_OK = "LOGOUT_OK"
    LOGOUT_FAILED = "LOGOUT_FAILED"
    DEVICE_FREE = "DEVICE_FREE"
    DEVICE_IN_USE = "DEVICE_IN_USE"
    CHECK_FAILED = "CHECK_FAILED"
    ACCEPTED = "ACCEPTED"
    REJECTED_ISN = "REJECTED_ISN"
    REJECTED_ROUTE = "REJECTED_ROUTE"
    REJECTED = "REJECTED"
    SESSION_INVALID = "SESSION_INVALID"
    UNKNOWN = "UNKNOWN"


_SUCCESS = {Outcome.LOGIN_OK, Outcome.LOGOUT_OK, Outcome.DEVICE_FREE,
            Outcome.DEVICE_IN_USE, Outcome.ACCEPTED}


@dataclass(frozen=True)
class Classified:
    outcome: Outcome
    ret: Optional[int]
    message: str
    detail: dict = field(default_factory=dict)
    extras: tuple = ()          # fields after p_msg (e.g. operator name)

    @property
    def ok(self) -> bool:
        return self.outcome in _SUCCESS


DELIM = "\x7f"


def parse_result(text: str) -> tuple[Optional[int], str, tuple]:
    """Return (p_ret, p_msg, extra_fields)."""
    t = (text or "").strip()
    if DELIM in t:
        parts = [p.strip() for p in t.split(DELIM)]
        ret = int(parts[0]) if parts[0] in ("0", "1") else None
        return ret, (parts[1] if len(parts) > 1 else ""), tuple(parts[2:])
    if t[:1] in ("0", "1"):
        return int(t[0]), t[1:].strip(), ()
    return None, t, ()


def split_result(text: str) -> tuple[Optional[int], str]:
    ret, msg, _ = parse_result(text)
    return ret, msg


def _has(low: str, *frags: str) -> bool:
    return any(f in low for f in frags)


def classify_login(text: str) -> Classified:
    ret, msg, extras = parse_result(text)
    low = msg.lower()
    if ret is None:
        return Classified(Outcome.UNKNOWN, ret, msg, {}, extras)
    if ret == 1:
        return Classified(Outcome.LOGIN_OK, ret, msg, {}, extras)
    if _has(low, "login twice"):
        o = Outcome.ALREADY_LOGGED_IN
    elif _has(low, "user not found"):
        o = Outcome.USER_NOT_FOUND
    elif _has(low, "device not defined"):
        o = Outcome.DEVICE_NOT_DEFINED
    else:
        o = Outcome.LOGIN_FAILED
    return Classified(o, ret, msg, {}, extras)


def classify_logout(text: str) -> Classified:
    ret, msg, extras = parse_result(text)
    if ret is None:
        return Classified(Outcome.UNKNOWN, ret, msg, {}, extras)
    return Classified(Outcome.LOGOUT_OK if ret == 1 else Outcome.LOGOUT_FAILED, ret, msg, {}, extras)


def classify_device_check(text: str) -> Classified:
    """status=5. Decided by the MESSAGE; p_ret is recorded but not trusted here
    (live service: p_ret=0 with an 'IN USED' answer; docs said 1)."""
    ret, msg, extras = parse_result(text)
    low = msg.lower()
    if ret is None and not low:
        return Classified(Outcome.UNKNOWN, ret, msg, {}, extras)
    if "device not defined" in low:
        return Classified(Outcome.DEVICE_NOT_DEFINED, ret, msg, {}, extras)
    if "not been used" in low:          # test first: it is the unambiguous one
        return Classified(Outcome.DEVICE_FREE, ret, msg, {}, extras)
    if "in used" in low:
        detail = {}
        for key, pat in (("operator", r"OP:\[(.*?)\]"), ("since", r"ON:\[(.*?)\]")):
            m = re.search(pat, msg, re.IGNORECASE)
            if m:
                detail[key] = m.group(1)
        return Classified(Outcome.DEVICE_IN_USE, ret, msg, detail, extras)
    if ret == 0:
        return Classified(Outcome.CHECK_FAILED, ret, msg, {}, extras)
    return Classified(Outcome.UNKNOWN, ret, msg, {}, extras)


def classify_transaction(text: str, session_invalid_markers: Iterable[str] = ()) -> Classified:
    ret, msg, extras = parse_result(text)
    low = msg.lower()
    if ret is None:
        return Classified(Outcome.UNKNOWN, ret, msg, {}, extras)
    if ret == 1:
        return Classified(Outcome.ACCEPTED, ret, msg, {}, extras)
    if any(m and m.lower() in low for m in session_invalid_markers):
        return Classified(Outcome.SESSION_INVALID, ret, msg)
    if _has(low, "wrong isn", "(chk_isn)"):
        o = Outcome.REJECTED_ISN
    elif _has(low, "wrong step", "route error"):
        o = Outcome.REJECTED_ROUTE
    else:
        o = Outcome.REJECTED
    return Classified(o, ret, msg, {}, extras)
