"""Executes ONE transaction and turns every possible outcome (including every
failure mode) into a TransactionResult, so a batch never dies on a single ISN."""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Mapping

from ..infrastructure.exceptions import (
    ConnectFailedError, DeviceMismatchError, HttpStatusError, NotAuthenticatedError,
    ReadTimeoutError, ResponseParseError, SessionError, SoapFaultError,
    TlsVerificationError, TransportError, ValidationError)
from ..integration.response_classifier import Classified, Outcome
from ..operations.definitions import Operation
from .validators import build_params

log = logging.getLogger("sfc_tool.transaction")


class Status(str, Enum):
    ACCEPTED = "ACCEPTED"     # server answered p_ret=1
    REJECTED = "REJECTED"     # server answered p_ret=0 (definitive)
    ERROR = "ERROR"           # failed locally / in transit; see category
    UNKNOWN = "UNKNOWN"       # may or may not have been processed: REVIEW
    SKIPPED = "SKIPPED"       # not sent (batch cancelled or aborted)


class Category(str, Enum):
    NONE = "NONE"
    ISN_INVALID = "ISN_INVALID"
    ROUTE = "ROUTE"
    SERVER_REJECTED = "SERVER_REJECTED"
    SESSION = "SESSION"
    VALIDATION = "VALIDATION"
    TIMEOUT = "TIMEOUT"
    CONNECTION = "CONNECTION"
    NETWORK = "NETWORK"
    TLS = "TLS"
    HTTP = "HTTP"
    SOAP_FAULT = "SOAP_FAULT"
    PARSE = "PARSE"
    UNRECOGNIZED = "UNRECOGNIZED"
    INTERNAL = "INTERNAL"
    CANCELLED = "CANCELLED"
    ABORTED = "ABORTED"


@dataclass(frozen=True)
class TransactionResult:
    operation: str
    isn: str
    status: Status
    category: Category
    message: str
    outcome: str = ""
    duration_ms: int = 0
    started_at: str = ""
    uncertain: bool = False   # True: the server may have processed it. Never auto-retry.

    @property
    def ok(self) -> bool:
        return self.status == Status.ACCEPTED


_FROM_OUTCOME = {
    Outcome.ACCEPTED: (Status.ACCEPTED, Category.NONE, False),
    Outcome.REJECTED_ISN: (Status.REJECTED, Category.ISN_INVALID, False),
    Outcome.REJECTED_ROUTE: (Status.REJECTED, Category.ROUTE, False),
    Outcome.REJECTED: (Status.REJECTED, Category.SERVER_REJECTED, False),
    Outcome.SESSION_INVALID: (Status.ERROR, Category.SESSION, False),
    Outcome.UNKNOWN: (Status.UNKNOWN, Category.UNRECOGNIZED, True),
}


class TransactionService:
    def __init__(self, session: Any) -> None:
        self._session = session        # SessionManager (or anything with execute()/device)

    @property
    def session(self) -> Any:
        return self._session

    def execute_one(self, op: Operation, base_params: Mapping[str, object], isn: str) -> TransactionResult:
        started = datetime.now().isoformat(timespec="seconds")
        t0 = time.perf_counter()

        def result(status, category, message, outcome="", uncertain=False):
            return TransactionResult(op.method, isn, status, category, message, outcome,
                                     int((time.perf_counter() - t0) * 1000), started, uncertain)
        try:
            params = build_params(op, base_params, isn)
            c: Classified = self._session.execute(op.method, params, isn=isn)
            status, category, uncertain = _FROM_OUTCOME.get(
                c.outcome, (Status.UNKNOWN, Category.UNRECOGNIZED, True))
            return result(status, category, c.message, c.outcome.value, uncertain)
        except ValidationError as e:
            return result(Status.ERROR, Category.VALIDATION, str(e))
        except ReadTimeoutError as e:
            return result(Status.UNKNOWN, Category.TIMEOUT, str(e), uncertain=True)
        except ConnectFailedError as e:
            return result(Status.ERROR, Category.CONNECTION, str(e))        # never sent
        except TlsVerificationError as e:
            return result(Status.ERROR, Category.TLS, str(e))               # never sent
        except HttpStatusError as e:
            return result(Status.UNKNOWN, Category.HTTP, "HTTP %s" % e.status, uncertain=True)
        except SoapFaultError as e:
            return result(Status.UNKNOWN, Category.SOAP_FAULT, str(e), uncertain=True)
        except ResponseParseError as e:
            return result(Status.UNKNOWN, Category.PARSE, str(e), uncertain=True)
        except TransportError as e:
            return result(Status.UNKNOWN, Category.NETWORK, str(e), uncertain=True)
        except (NotAuthenticatedError, DeviceMismatchError, SessionError) as e:
            cat = Category.VALIDATION if isinstance(e, DeviceMismatchError) else Category.SESSION
            return result(Status.ERROR, cat, str(e))
        except Exception as e:  # a bug must not be silent, and must not be retried blindly
            log.exception("transaction_internal_error")
            return result(Status.ERROR, Category.INTERNAL, "Internal error: %s" % type(e).__name__, uncertain=True)
