r"""MANUAL batch run against the QA service: login -> transactions -> logout.

WARNING: this sends REAL transactions (WTSP_RESULT / WTSP_RESULT_MASSDATA) to QA
and data is saved there. It asks for explicit confirmation (type YES) first.
    $env:PYTHONPATH = "src"        (PowerShell)    |    set PYTHONPATH=src   (cmd)
    python scripts\manual_batch_check.py
"""
import getpass
import os
import threading
from datetime import datetime

from sfc_tool.application.batch_runner import BatchRunner
from sfc_tool.application.exporter import export_results_csv
from sfc_tool.application.session_manager import Credentials, SessionManager
from sfc_tool.application.transaction_service import TransactionService
from sfc_tool.application.validators import parse_isn_list
from sfc_tool.infrastructure.logging_setup import setup_logging
from sfc_tool.infrastructure.settings import load_settings
from sfc_tool.integration.soap_client import SoapClient
from sfc_tool.operations.definitions import OPERATIONS


def ask(label, default=""):
    """Enter keeps the default shown in [ ]; a single '-' sends an EMPTY value."""
    shown = "[%s]" % default if default != "" else "[empty]"
    v = input("%s %s (Enter=keep, -=empty): " % (label, shown))
    if v.strip() == "-":
        return ""
    return v if v != "" else default


def main():
    s = load_settings()
    setup_logging(s.log_dir, s.log_level)
    c = Credentials(
        program_id=input("programId: "), program_password=getpass.getpass("programPassword: "),
        op=input("op: "), password=getpass.getpass("password: "),
        device=input("device: "), tsp=ask("TSP", "SFIS"))
    m = SessionManager(SoapClient(s), s)
    try:
        chk = m.check_device(c)
        print("Device check:", chk.outcome.value, "|", chk.message)
        r = m.login(c)
        print("Login:", r.outcome.value, "|", r.message)
        if r.outcome.value == "ALREADY_LOGGED_IN" and m.has_pending_conflict:
            if not chk.detail.get("same_operator"):
                print("Logged in by another operator; stopping."); m.cancel_pending(); return
            if input("Stale session of YOUR operator. Log it out and re-login? (y/N) ").lower() != "y":
                m.cancel_pending(); return
            r = m.recover_already_logged_in(confirmed=True)
            print("Recovery:", r.outcome.value)
        if m.state.value != "AUTHENTICATED":
            return

        op = OPERATIONS["WTSP_RESULT_MASSDATA" if ask("Operation 1=RESULT 2=MASSDATA", "1") == "2" else "WTSP_RESULT"]
        params = {"device": c.device, "TSP": c.tsp}
        for k in op.params:
            if k not in ("ISN", "device", "TSP"):
                params[k] = ask(k, op.defaults.get(k, ""))
        print("Paste ISNs, one per line. Empty line to finish:")
        lines = []
        while True:
            line = input()
            if not line.strip():
                break
            lines.append(line)
        parsed = parse_isn_list("\n".join(lines))
        for n, raw, why in parsed.invalid:
            print("  skipped line %d (%r): %s" % (n, raw, why))
        if parsed.duplicates:
            print("  duplicates dropped:", ", ".join(parsed.duplicates))
        if not parsed.isns:
            print("Nothing to send."); return
        print("Parameters sent with EVERY ISN (an empty value is sent as empty):")
        for k in op.params:
            if k != "ISN":
                print("   %-9s= %r" % (k, params.get(k, op.defaults.get(k, ""))))
        if input("Send %d REAL transaction(s) to QA device %s? Type YES: " % (len(parsed.isns), c.device)) != "YES":
            print("Cancelled."); return

        cancel = threading.Event()
        try:
            summary = BatchRunner(TransactionService(m)).run(
                op, params, parsed.isns, cancel=cancel,
                on_progress=lambda d, t, res: print("  [%d/%d] %s -> %s/%s %s%s" % (
                    d, t, res.isn, res.status.value, res.category.value, res.message[:150],
                    "  <-- REVIEW (may have been processed)" if res.uncertain else "")))
        except KeyboardInterrupt:
            cancel.set(); print("Interrupted."); return
        print("\nSummary:", summary.counts_by_status(), summary.counts_by_category(),
              "| %.1fs" % summary.duration_s, "| aborted:", summary.aborted_reason or "no")
        os.makedirs(s.log_dir, exist_ok=True)
        path = os.path.join(s.log_dir, "batch_%s.csv" % datetime.now().strftime("%Y%m%d_%H%M%S"))
        export_results_csv(summary.results, path)
        print("Results exported to", path)
    finally:
        out = m.shutdown()
        print("Logout on exit:", (out.outcome.value + " | " + out.message) if out else "nothing to log out")


if __name__ == "__main__":
    main()
