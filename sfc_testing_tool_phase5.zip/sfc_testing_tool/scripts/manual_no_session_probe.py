r"""PROBE: send ONE transaction WITHOUT logging in, to learn how the server answers
when no session exists (needed to detect an expired session later).

This deliberately bypasses the tool's local "must be logged in" guard. Use it only:
  * with the device logged OUT (do not log in during this probe);
  * with the obviously fake ISN below, which the server should reject anyway.

    $env:PYTHONPATH = "src"          (PowerShell)   |   set PYTHONPATH=src   (cmd)
    python scripts\manual_no_session_probe.py
"""
import getpass

from sfc_tool.application.validators import build_params
from sfc_tool.infrastructure.logging_setup import setup_logging
from sfc_tool.infrastructure.settings import load_settings
from sfc_tool.integration.response_classifier import classify_transaction
from sfc_tool.integration.soap_client import SoapClient
from sfc_tool.operations.definitions import OPERATIONS

FAKE_ISN = "TEST-NO-SESSION-PROBE"


def main():
    s = load_settings()
    setup_logging(s.log_dir, s.log_level)
    program_id = input("programId: ")
    program_password = getpass.getpass("programPassword: ")
    device = input("device (must be logged OUT): ")
    op = OPERATIONS["WTSP_RESULT"]
    params = build_params(op, {"device": device, "error": "", "status": "1"}, FAKE_ISN)
    params = [("programId", program_id), ("programPassword", program_password)] + params
    print("Sending ONE request: ISN=%r, error='', status='1' (no login)" % FAKE_ISN)
    if input("Type YES to send: ") != "YES":
        print("Cancelled."); return
    resp = SoapClient(s).call(op.method, params, isn=FAKE_ISN)
    print("raw result text:", repr(resp.result_text))
    c = classify_transaction(resp.result_text, s.session_invalid_markers)
    print("classified as:", c.outcome.value, "| ret:", c.ret, "| message:", c.message)


if __name__ == "__main__":
    main()
