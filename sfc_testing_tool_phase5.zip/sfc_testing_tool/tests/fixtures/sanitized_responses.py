"""Result-element texts captured from the real service, with identities replaced.

Wire format: p_ret char immediately followed by p_msg (+ optional trailer).
"""
LOGIN_OK = "1Welcome using Pegatron SFIS:XXXX(LAST,FIRST)LAST,FIRSTOP"
LOGIN_TWICE = "0Login Twice! SN:10 (D_LOGIN)(TSP_LOGIN)"
RESULT_OK = "1SFIS:ISN OK!!(U)(SM) TEST DATA:SAVED! STATUS:[1] (TSP_TRESULT)310010"
RESULT_BAD_ISN = "0EC1:[0]WRONG ISN:[0]LENGTH !(CHK_ISN)?[M1](SM)(TSP_TRESULT)310010"
# From the protocol documentation (not yet captured from the live service):
LOGIN_USER_NOT_FOUND = "0USER NOT FOUND!(TSP_LOGIN)"
LOGIN_DEVICE_UNDEFINED = "0DEVICE NOT DEFINED!(TSP_LOGIN)"
LOGOUT_OK = "1THANK YOU USING PEGATRON SFIS!(LO)"
CHECK_IN_USE = "1DEV:[123456]IN USED!OP:[P1234] ON:[2006/01/01 08:00:05] (TSP_LOGIN)"
CHECK_FREE = "1DEV:[123456] NOT BEEN USED! (TSP_LOGIN)"
RESULT_WRONG_STEP = "0SFIS DOC..31 WRONG STEP: SFIS test route ROUTE error(TSP_TRESULT)310010"
# Captured live (identities replaced): fields are separated by 0x7F.
LIVE_CHECK_IN_USE = "0\x7f DEV:[310010]IN USED!OP:[XXXX] ON:[2026/11/09 01:17:25](TSP_LOGIN)\x7fLAST,FIRST"
# Captured live in the full-session run (identities replaced), 0x7F-delimited:
LIVE_LOGIN_OK = "1\x7fWelcome using Pegatron SFIS:XXXX(LAST,FIRST)\x7fLAST,FIRSTOP"
LIVE_LOGOUT_OK = "1\x7fThank you for using Pegatron SFIS!\n(LO)\x7fLAST,FIRSTLOGOUT SFIS"
LIVE_CHECK_FREE = "1\x7f DEV:[310010] NOT BEEN USED!\x7fLAST,FIRST"
LIVE_LOGIN_TWICE = "0\x7fLogin Twice! SN:10 (D_LOGIN)(TSP_LOGIN)\x7f"
# Captured live (values replaced). Accepted with status=1 and EMPTY error:
LIVE_RESULT_OK = "1\x7fSFIS:ISN OK!!(U)(SM) TEST DATA:SAVED! STATUS:[1] (TSP_TRESULT)\x7f"
LIVE_RESULT_MO_NOT_APPROVED = "0\x7fLOOP[0] T1 SFIS:The MO:00000000 Not Approval !(U)?[L](SM)(TSP_TRESULT)\x7f"
LIVE_RESULT_ROUTE = "0\x7fLOOP[0] T1 SFIS:MO_D.ROUTE/GRP:GRP01_MB/TB2ROUTE_STEP[GRP01_MB/TB2]\x7f"
