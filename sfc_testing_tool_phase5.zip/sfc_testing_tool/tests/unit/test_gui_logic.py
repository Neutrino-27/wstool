import dataclasses
import unittest
from concurrent.futures import Future

from sfc_tool.application.batch_runner import BatchRunner
from sfc_tool.application.session_manager import Credentials, SessionManager, SessionState as S
from sfc_tool.application.transaction_service import TransactionService
from sfc_tool.infrastructure.exceptions import ValidationError
from sfc_tool.integration.response_classifier import Outcome, classify_device_check
from sfc_tool.operations.definitions import OPERATIONS
from sfc_tool.presentation.controller import AppController
from sfc_tool.presentation import view_models as vm
from tests.fixtures import sanitized_responses as F
from .helpers import SETTINGS
from .test_session_manager import FakeClient

R = OPERATIONS["WTSP_RESULT"]


class SyncExecutor:
    def submit(self, fn, *a):
        fut = Future()
        try:
            fut.set_result(fn(*a))
        except BaseException as e:
            fut.set_exception(e)
        return fut

    def shutdown(self, wait=False):
        pass


def make(*script):
    client = FakeClient(*script)
    session = SessionManager(client, SETTINGS)
    events = []
    ctl = AppController(session, BatchRunner(TransactionService(session)), events.append, SyncExecutor())
    return ctl, client, events


def kinds(events):
    return [e.kind for e in events]


def creds(op="XXXX"):
    return Credentials("PID", "PW1", op, "PW2", "310010")


class Controller(unittest.TestCase):
    def test_login_success_events_in_order(self):
        ctl, _, ev = make(F.LIVE_LOGIN_OK)
        self.assertTrue(ctl.login(creds()))
        self.assertEqual(kinds(ev), ["busy", "session_state", "session_state", "login_result", "busy"])
        self.assertEqual([e.data for e in ev if e.kind == "busy"], [True, False])
        self.assertEqual((ev[-2].data.outcome, ctl.state, ctl.busy), (Outcome.LOGIN_OK, S.AUTHENTICATED, False))

    def test_login_twice_asks_and_never_auto_resolves(self):
        ctl, client, ev = make(F.LIVE_LOGIN_TWICE, F.LIVE_CHECK_IN_USE)
        ctl.login(creds())
        conflict = [e for e in ev if e.kind == "login_conflict"][0].data
        self.assertEqual(conflict["login"].outcome, Outcome.ALREADY_LOGGED_IN)
        self.assertEqual(conflict["check"].outcome, Outcome.DEVICE_IN_USE)
        self.assertTrue(conflict["check"].detail["same_operator"])
        self.assertEqual(client.statuses(), ["1", "5"])             # nothing was logged out

    def test_conflict_declined_leaves_server_untouched(self):
        ctl, client, ev = make(F.LIVE_LOGIN_TWICE, F.LIVE_CHECK_IN_USE)
        ctl.login(creds()); ctl.resolve_conflict(False)
        self.assertEqual(client.statuses(), ["1", "5"])
        self.assertEqual(ctl.state, S.DISCONNECTED)

    def test_conflict_confirmed_logs_out_then_in(self):
        ctl, client, ev = make(F.LIVE_LOGIN_TWICE, F.LIVE_CHECK_IN_USE, F.LIVE_LOGOUT_OK, F.LIVE_LOGIN_OK)
        ctl.login(creds()); ctl.resolve_conflict(True)
        self.assertEqual(client.statuses(), ["1", "5", "2", "1"])
        self.assertEqual((ctl.state, ctl.busy), (S.AUTHENTICATED, False))
        self.assertEqual([e for e in ev if e.kind == "login_result"][-1].data.outcome, Outcome.LOGIN_OK)

    def test_logout(self):
        ctl, _, ev = make(F.LIVE_LOGIN_OK, F.LIVE_LOGOUT_OK)
        ctl.login(creds()); ctl.logout()
        self.assertEqual([e for e in ev if e.kind == "logout_result"][0].data.outcome, Outcome.LOGOUT_OK)
        self.assertEqual(ctl.state, S.DISCONNECTED)

    def test_batch_progress_and_done(self):
        ctl, _, ev = make(F.LIVE_LOGIN_OK, F.RESULT_OK, F.RESULT_BAD_ISN)
        ctl.login(creds())
        ctl.run_batch(R, {"device": "310010", "error": "", "status": "1"}, ["A", "B"])
        self.assertEqual([e.data[0] for e in ev if e.kind == "progress"], [1, 2])
        started = [e for e in ev if e.kind == "batch_started"][0]
        done = [e for e in ev if e.kind == "batch_done"][0].data
        self.assertEqual((started.data, done.counts_by_status()), (2, {"ACCEPTED": 1, "REJECTED": 1}))

    def test_job_errors_become_error_events_and_busy_resets(self):
        ctl, client, ev = make()
        ctl.run_batch(R, {"device": "310010"}, ["A"])               # not authenticated
        self.assertIn("error", kinds(ev))
        self.assertEqual((ev[-1].kind, ev[-1].data, ctl.busy), ("busy", False, False))
        self.assertEqual(client.calls, [])

    def test_unexpected_exception_does_not_crash(self):
        ctl, client, ev = make(RuntimeError("boom"))
        ctl.login(creds())
        err = [e.data for e in ev if e.kind == "error"][0]
        self.assertIn("Unexpected error", err); self.assertNotIn("boom", err)
        self.assertEqual(ctl.state, S.DISCONNECTED)

    def test_double_submit_ignored_while_busy(self):
        ctl, _, _ = make(F.LIVE_LOGIN_OK)
        ctl._jobs = 1                                                # simulate a running job
        self.assertFalse(ctl.login(creds()))

    def test_shutdown_logs_out_and_signals_closed(self):
        ctl, client, ev = make(F.LIVE_LOGIN_OK, F.LIVE_LOGOUT_OK)
        ctl.login(creds()); ctl.shutdown()
        self.assertEqual(client.statuses(), ["1", "2"])
        self.assertIn("closed", kinds(ev)); self.assertEqual(ctl.state, S.DISCONNECTED)

    def test_shutdown_when_disconnected_still_closes(self):
        ctl, client, ev = make()
        ctl.shutdown()
        self.assertEqual((kinds(ev)[-2:], client.calls), (["closed", "busy"], []))


class ViewModels(unittest.TestCase):
    def test_parse_credentials(self):
        c = vm.parse_credentials({"programId": " P ", "op": "O", "device": "1", "TSP": "SFIS", "password": "x"})
        self.assertEqual((c.program_id, c.device, c.program_password), ("P", "1", ""))
        with self.assertRaises(ValidationError):
            vm.parse_credentials({"programId": "P", "op": "", "device": "1", "TSP": "SFIS"})

    def test_collect_params_keeps_empty_and_forces_session_device(self):
        p = vm.collect_params(R, {"error": "", "data": " X ", "status": "1", "device": "HACK"}, "310010")
        self.assertEqual((p["error"], p["data"], p["status"], p["device"]), ("", "X", "1", "310010"))
        self.assertNotIn("ISN", p)

    def test_rows_and_tags(self):
        ctl, _, ev = make(F.LIVE_LOGIN_OK, F.RESULT_OK, F.RESULT_BAD_ISN, "???")
        ctl.login(creds())
        ctl.run_batch(R, {"device": "310010", "status": "1"}, ["A", "B", "C"])
        summ = [e for e in ev if e.kind == "batch_done"][0].data
        tags = [vm.tag_for(r) for r in summ.results]
        self.assertEqual(tags, ["accepted", "rejected", "review"])
        row = vm.result_row(3, summ.results[2])
        self.assertEqual((row[0], row[2], row[3], row[5]), (3, "C", "UNKNOWN", "REVIEW"))
        line = vm.summary_line(summ)
        self.assertIn("3 ISN", line); self.assertIn("1 need REVIEW", line); self.assertIn("ISN_INVALID 1", line)

    def test_summary_flags_cancel_and_abort(self):
        ctl, _, ev = make(F.LIVE_LOGIN_OK)
        ctl.login(creds()); ctl._cancel.set()
        from sfc_tool.application.batch_runner import BatchSummary
        bs = BatchSummary("M", "d", "t", cancelled=True); self.assertIn("CANCELLED", vm.summary_line(bs))
        bs = BatchSummary("M", "d", "t", aborted_reason="Aborted: TLS"); self.assertIn("Aborted: TLS", vm.summary_line(bs))

    def test_conflict_message_variants(self):
        mine = classify_device_check(F.LIVE_CHECK_IN_USE)
        mine = dataclasses.replace(mine, detail=dict(mine.detail, same_operator=True))
        text, same = vm.conflict_message(mine, "310010")
        self.assertTrue(same); self.assertIn("YOUR OWN", text)
        other = dataclasses.replace(mine, detail=dict(mine.detail, same_operator=False))
        text, same = vm.conflict_message(other, "310010")
        self.assertFalse(same); self.assertIn("ANOTHER operator", text)
        text, same = vm.conflict_message(None, "310010")
        self.assertIn("holder unknown", text)


if __name__ == "__main__":
    unittest.main()
