import csv
import os
import tempfile
import threading
import unittest

from sfc_tool.application.batch_runner import BatchRunner
from sfc_tool.application.exporter import COLUMNS, export_results_csv
from sfc_tool.application.session_manager import Credentials, SessionManager
from sfc_tool.application.transaction_service import Category as C, Status as S, TransactionService
from sfc_tool.infrastructure.exceptions import (
    ConnectFailedError, DeviceMismatchError, HttpStatusError, NotAuthenticatedError,
    ReadTimeoutError, ResponseParseError, SoapFaultError, TlsVerificationError,
    TransportError, ValidationError)
from sfc_tool.integration.response_classifier import classify_transaction
from sfc_tool.operations.definitions import OPERATIONS
from tests.fixtures import sanitized_responses as F
from .helpers import SETTINGS
from .test_session_manager import FakeClient

import dataclasses
R = OPERATIONS["WTSP_RESULT"]
BASE = {"device": "310010"}


def cl(text, markers=()):
    return classify_transaction(text, markers)


OK, BAD, ROUTE = cl(F.RESULT_OK), cl(F.RESULT_BAD_ISN), cl(F.RESULT_WRONG_STEP)


class FakeMgr:
    """Scripted stand-in for SessionManager: items are Classified or exceptions."""
    def __init__(self, *script, device="310010"):
        self.script, self.calls, self.device = list(script), [], device

    def execute(self, method, params, isn=""):
        self.calls.append((method, list(params), isn))
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


def svc(*script, **kw):
    m = FakeMgr(*script, **kw)
    return TransactionService(m), m


class Service(unittest.TestCase):
    def one(self, item):
        s, _ = svc(item)
        return s.execute_one(R, BASE, "SN1")

    def check(self, item, status, category, uncertain):
        r = self.one(item)
        self.assertEqual((r.status, r.category, r.uncertain), (status, category, uncertain), r.message)
        return r

    def test_accepted(self):
        r = self.check(OK, S.ACCEPTED, C.NONE, False)
        self.assertTrue(r.ok); self.assertEqual(r.outcome, "ACCEPTED")

    def test_server_rejections_are_definitive(self):
        self.check(BAD, S.REJECTED, C.ISN_INVALID, False)
        self.check(ROUTE, S.REJECTED, C.ROUTE, False)
        self.check(cl("0\x7fother"), S.REJECTED, C.SERVER_REJECTED, False)
        self.check(cl(F.LIVE_RESULT_MO_NOT_APPROVED), S.REJECTED, C.MO_NOT_APPROVED, False)
        self.check(cl(F.LIVE_RESULT_ROUTE), S.REJECTED, C.ROUTE, False)

    def test_unrecognized_response_is_unknown_not_success(self):
        self.check(cl("???"), S.UNKNOWN, C.UNRECOGNIZED, True)

    def test_transport_failures(self):
        self.check(ReadTimeoutError("x"), S.UNKNOWN, C.TIMEOUT, True)        # may have been saved!
        self.check(ConnectFailedError("x"), S.ERROR, C.CONNECTION, False)    # provably not sent
        self.check(TlsVerificationError("x"), S.ERROR, C.TLS, False)
        self.check(HttpStatusError(503), S.UNKNOWN, C.HTTP, True)
        self.check(SoapFaultError("c", "boom", 500), S.UNKNOWN, C.SOAP_FAULT, True)
        self.check(ResponseParseError("x"), S.UNKNOWN, C.PARSE, True)
        self.check(TransportError("x"), S.UNKNOWN, C.NETWORK, True)

    def test_session_and_internal(self):
        self.check(NotAuthenticatedError("x"), S.ERROR, C.SESSION, False)
        self.check(DeviceMismatchError("x"), S.ERROR, C.VALIDATION, False)
        self.check(cl("0\x7fplease login first", ["login first"]), S.ERROR, C.SESSION, False)
        self.check(RuntimeError("bug"), S.ERROR, C.INTERNAL, True)

    def test_validation_error_never_reaches_session(self):
        s, m = svc()
        r = s.execute_one(R, {}, "SN1")
        self.assertEqual((r.category, m.calls), (C.VALIDATION, []))

    def test_result_has_timing_and_isn(self):
        r = self.one(OK)
        self.assertEqual((r.isn, r.operation), ("SN1", "WTSP_RESULT"))
        self.assertTrue(r.started_at)


class Batch(unittest.TestCase):
    def run_batch(self, script, isns, **kw):
        s, m = svc(*script)
        runner = BatchRunner(s, **{k: v for k, v in kw.items() if k == "max_consecutive_transport_errors"})
        return runner.run(R, BASE, isns, **{k: v for k, v in kw.items() if k != "max_consecutive_transport_errors"}), m

    def test_rejection_does_not_stop_batch(self):
        sm, m = self.run_batch([OK, BAD, ROUTE, OK], ["A", "B", "C", "D"])
        self.assertEqual(len(m.calls), 4)
        self.assertEqual(sm.counts_by_status(), {"ACCEPTED": 2, "REJECTED": 2})
        self.assertEqual(sm.counts_by_category(), {"ISN_INVALID": 1, "ROUTE": 1})
        self.assertFalse(sm.all_accepted); self.assertIsNone(sm.aborted_reason)

    def test_all_accepted(self):
        sm, _ = self.run_batch([OK, OK], ["A", "B"])
        self.assertTrue(sm.all_accepted)
        self.assertEqual((sm.total, sm.device, sm.operation), (2, "310010", "WTSP_RESULT"))

    def test_timeout_is_recorded_and_batch_continues_never_retried(self):
        sm, m = self.run_batch([ReadTimeoutError("t"), OK], ["A", "B"])
        self.assertEqual([r.status for r in sm.results], [S.UNKNOWN, S.ACCEPTED])
        self.assertEqual([c[2] for c in m.calls], ["A", "B"])        # A sent once only
        self.assertEqual([r.isn for r in sm.needs_review], ["A"])

    def test_consecutive_connection_failures_abort_and_skip_rest(self):
        e = ConnectFailedError
        sm, m = self.run_batch([e("x"), e("x"), e("x"), OK, OK], list("ABCDE"))
        self.assertEqual(len(m.calls), 3)
        self.assertEqual(sm.counts_by_status(), {"ERROR": 3, "SKIPPED": 2})
        self.assertIn("3 consecutive", sm.aborted_reason)
        self.assertEqual([r.isn for r in sm.results], list("ABCDE"))   # nothing silently dropped

    def test_breaker_resets_on_success_or_rejection(self):
        e = ConnectFailedError
        sm, m = self.run_batch([e("x"), e("x"), BAD, e("x"), e("x"), OK], list("ABCDEF"))
        self.assertEqual(len(m.calls), 6); self.assertIsNone(sm.aborted_reason)

    def test_tls_and_session_abort_immediately(self):
        sm, m = self.run_batch([TlsVerificationError("x"), OK], ["A", "B"])
        self.assertEqual((len(m.calls), sm.results[1].status, sm.results[1].category), (1, S.SKIPPED, C.ABORTED))
        sm, m = self.run_batch([OK, NotAuthenticatedError("x"), OK], ["A", "B", "C"])
        self.assertEqual(len(m.calls), 2); self.assertIn("SESSION", sm.aborted_reason)

    def test_cancel_stops_before_next_isn(self):
        ev = threading.Event()
        sm, m = self.run_batch([OK, OK, OK], ["A", "B", "C"], cancel=ev,
                               on_progress=lambda d, t, r: ev.set() if d == 1 else None)
        self.assertEqual(len(m.calls), 1)
        self.assertTrue(sm.cancelled)
        self.assertEqual([r.category for r in sm.results[1:]], [C.CANCELLED, C.CANCELLED])

    def test_preflight_blocks_before_any_traffic(self):
        s, m = svc(OK)
        runner = BatchRunner(s)
        with self.assertRaises(ValidationError): runner.run(R, BASE, [])
        with self.assertRaises(ValidationError): runner.run(R, {}, ["A"])
        with self.assertRaises(DeviceMismatchError): runner.run(R, {"device": "999"}, ["A"])
        s2, _ = svc(OK, device=None)
        with self.assertRaises(NotAuthenticatedError): BatchRunner(s2).run(R, BASE, ["A"])
        self.assertEqual(m.calls, [])

    def test_progress_reported_and_callback_errors_ignored(self):
        seen = []
        sm, _ = self.run_batch([OK, OK], ["A", "B"], on_progress=lambda d, t, r: (seen.append((d, t)), 1 / 0))
        self.assertEqual(seen, [(1, 2), (2, 2)]); self.assertEqual(sm.total, 2)


class Export(unittest.TestCase):
    def test_csv_columns_content_and_formula_safety(self):
        s, _ = svc(OK, cl("0\x7f=HYPERLINK(\"evil\")"))
        sm = BatchRunner(s).run(R, BASE, ["A", "=B1"])
        path = os.path.join(tempfile.mkdtemp(), "out.csv")
        self.assertEqual(export_results_csv(sm.results, path), 2)
        with open(path, encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.reader(fh))
        self.assertEqual(rows[0], COLUMNS)
        self.assertEqual(rows[1][2:5], ["A", "ACCEPTED", "NONE"])
        self.assertEqual(rows[2][2], "'=B1")
        self.assertTrue(rows[2][6].startswith("'="))
        with open(path, encoding="utf-8-sig") as fh:
            self.assertNotIn("password", fh.read().lower())


class EndToEnd(unittest.TestCase):
    """Real SessionManager + real classifier + scripted wire responses."""
    def test_login_batch_logout(self):
        st = dataclasses.replace(SETTINGS, session_invalid_markers=[])
        client = FakeClient(F.LIVE_LOGIN_OK, F.RESULT_OK, F.RESULT_BAD_ISN, F.RESULT_OK, F.LIVE_LOGOUT_OK)
        sess = SessionManager(client, st)
        sess.login(Credentials("PID", "SECRET-PW", "OP1", "SECRET-PW2", "310010"))
        sm = BatchRunner(TransactionService(sess)).run(
            OPERATIONS["WTSP_RESULT"], BASE, ["A", "B", "C"])
        self.assertEqual([r.status for r in sm.results], [S.ACCEPTED, S.REJECTED, S.ACCEPTED])
        self.assertEqual(sm.results[1].category, C.ISN_INVALID)
        wire = [dict(p) for _, p, _ in client.calls[1:4]]
        self.assertEqual([w["ISN"] for w in wire], ["A", "B", "C"])
        self.assertTrue(all(w["programPassword"] == "SECRET-PW" for w in wire))   # injected by session
        sess.logout()
        self.assertEqual(client.statuses()[-1], "2")


if __name__ == "__main__":
    unittest.main()
