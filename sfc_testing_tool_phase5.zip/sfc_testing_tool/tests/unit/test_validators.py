import unittest

from sfc_tool.application.validators import build_params, collect_isns, parse_isn_list
from sfc_tool.infrastructure.exceptions import ValidationError
from sfc_tool.operations.definitions import OPERATIONS

R, M = OPERATIONS["WTSP_RESULT"], OPERATIONS["WTSP_RESULT_MASSDATA"]
BASE = {"device": "310010"}


class IsnParsing(unittest.TestCase):
    def test_blank_lines_and_trimming(self):
        self.assertEqual(parse_isn_list("  A1 \n\n B2\r\n").isns, ["A1", "B2"])

    def test_whitespace_inside_is_invalid_not_dropped_silently(self):
        r = parse_isn_list("A1\nB 2\nC3")
        self.assertEqual(r.isns, ["A1", "C3"])
        self.assertEqual(r.invalid, [(2, "B 2", "contains whitespace")])

    def test_control_characters_invalid(self):
        self.assertEqual(parse_isn_list("A\x00B").invalid[0][2], "contains control characters")

    def test_duplicates_reported_and_optional(self):
        r = parse_isn_list("A\nB\nA")
        self.assertEqual((r.isns, r.duplicates), (["A", "B"], ["A"]))
        self.assertEqual(parse_isn_list("A\nA", allow_duplicates=True).isns, ["A", "A"])

    def test_no_invented_length_rules(self):
        self.assertEqual(parse_isn_list("X").isns, ["X"])
        self.assertEqual(len(parse_isn_list("9" * 500).isns), 1)

    def test_batch_text_wins_over_single(self):
        self.assertEqual(collect_isns("S1", "B1\nB2").isns, ["B1", "B2"])
        self.assertEqual(collect_isns("S1", "  \n").isns, ["S1"])
        self.assertEqual(collect_isns("", "").isns, [])


class Params(unittest.TestCase):
    def test_order_defaults_and_isn(self):
        p = build_params(R, BASE, "SN1")
        self.assertEqual([k for k, _ in p], list(R.params))
        d = dict(p)
        self.assertEqual((d["ISN"], d["error"], d["TSP"], d["data"], d["status"], d["CPKFlag"]),
                         ("SN1", "", "SFIS", "TEST", "8", ""))

    def test_explicit_empty_value_is_sent_empty_not_replaced_by_default(self):
        d = dict(build_params(R, dict(BASE, error="", data="", status="1"), "SN1"))
        self.assertEqual((d["error"], d["data"], d["status"]), ("", "", "1"))
        self.assertEqual(dict(build_params(R, BASE, "SN1"))["error"], "")    # empty by default
        self.assertEqual(dict(build_params(R, dict(BASE, error="5"), "SN1"))["error"], "5")  # set only when needed

    def test_massdata_extended_params(self):
        p = build_params(M, dict(BASE, aoiloc="LOC", data3="x"), "SN1")
        self.assertEqual([k for k, _ in p][-8:], ["aoiloc", "data2", "data3", "data4", "data5", "data6", "data7", "data8"])
        self.assertEqual(dict(p)["aoiloc"], "LOC")

    def test_unknown_param_rejected(self):
        with self.assertRaises(ValidationError):
            build_params(R, dict(BASE, bogus="1"), "SN1")
        with self.assertRaises(ValidationError):
            build_params(R, dict(BASE, aoiloc="x"), "SN1")    # MASSDATA-only field

    def test_required_and_isn(self):
        with self.assertRaises(ValidationError): build_params(R, {}, "SN1")
        with self.assertRaises(ValidationError): build_params(R, dict(BASE, TSP=" "), "SN1")
        with self.assertRaises(ValidationError): build_params(R, BASE, "")


if __name__ == "__main__":
    unittest.main()
