"""Pure presentation helpers (no tkinter): formatting, form -> domain objects."""
from __future__ import annotations

from typing import Mapping, Optional

from ..application.batch_runner import BatchSummary
from ..application.session_manager import Credentials, SessionState
from ..application.transaction_service import Status, TransactionResult
from ..infrastructure.exceptions import ValidationError
from ..integration.response_classifier import Classified, Outcome
from ..operations.definitions import Operation

SESSION_COLORS = {
    SessionState.DISCONNECTED: "#7a7a7a",
    SessionState.AUTHENTICATING: "#d19a00",
    SessionState.AUTHENTICATED: "#1e8e3e",
    SessionState.LOGGING_OUT: "#d19a00",
    SessionState.SESSION_EXPIRED: "#c62828",
}
SESSION_LABELS = {
    SessionState.DISCONNECTED: "Disconnected",
    SessionState.AUTHENTICATING: "Logging in...",
    SessionState.AUTHENTICATED: "Authenticated",
    SessionState.LOGGING_OUT: "Logging out...",
    SessionState.SESSION_EXPIRED: "Session expired",
}

CRED_FIELDS = ("programId", "programPassword", "op", "password", "device", "TSP")
_REQUIRED = ("programId", "op", "device", "TSP")


def parse_credentials(values: Mapping[str, str]) -> Credentials:
    v = {k: (values.get(k) or "").strip() for k in CRED_FIELDS}
    missing = [k for k in _REQUIRED if not v[k]]
    if missing:
        raise ValidationError("Required login field(s) empty: %s" % ", ".join(missing))
    return Credentials(v["programId"], v["programPassword"], v["op"], v["password"], v["device"], v["TSP"])


def collect_params(op: Operation, values: Mapping[str, str], device: str) -> dict:
    """Form values -> parameter dict exactly as shown (empty stays empty)."""
    out = {k: (values.get(k) or "").strip() for k in op.params if k != "ISN"}
    out["device"] = (device or "").strip()
    return out


def tag_for(r: TransactionResult) -> str:
    if r.uncertain:
        return "review"
    return {Status.ACCEPTED: "accepted", Status.REJECTED: "rejected",
            Status.ERROR: "error", Status.SKIPPED: "skipped"}.get(r.status, "review")


def result_row(n: int, r: TransactionResult) -> tuple:
    time_part = r.started_at.split("T")[-1] if r.started_at else ""
    return (n, time_part, r.isn, r.status.value, r.category.value,
            "REVIEW" if r.uncertain else "", " ".join(r.message.split()), r.duration_ms)


def summary_line(s: BatchSummary) -> str:
    parts = ["%d ISN" % s.total] + ["%s %d" % kv for kv in s.counts_by_status().items()]
    line = " | ".join([parts[0], " · ".join(parts[1:]) or "-"])
    cats = s.counts_by_category()
    if cats:
        line += " | " + ", ".join("%s %d" % kv for kv in cats.items())
    line += " | %.1f s" % s.duration_s
    if s.needs_review:
        line += " | %d need REVIEW" % len(s.needs_review)
    if s.cancelled:
        line += " | CANCELLED"
    elif s.aborted_reason:
        line += " | " + s.aborted_reason
    return line


def conflict_message(check: Optional[Classified], device: str) -> tuple[str, bool]:
    """(dialog text, held_by_same_operator)."""
    if check is not None and check.outcome == Outcome.DEVICE_IN_USE:
        who = check.detail.get("operator", "unknown")
        since = check.detail.get("since", "unknown time")
        same = bool(check.detail.get("same_operator"))
        head = "Device %s is already logged in by operator %s (since %s).\n\n" % (device, who, since)
        if same:
            tail = "This looks like YOUR OWN leftover session."
        else:
            tail = ("WARNING: this is ANOTHER operator's session. Logging it out may "
                    "interrupt their work.")
        return head + tail + "\n\nLog that session out and log in again?", same
    return ("Device %s is already logged in (holder unknown).\n\n"
            "Log that session out and log in again?" % device), False
