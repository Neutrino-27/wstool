"""GUI controller: NO tkinter here, so it is fully testable.

All network work runs on ONE background worker thread (jobs are serialized, which
also keeps the web-service traffic sequential). The worker never touches widgets:
it emits UiEvent objects through `emit` (a thread-safe queue.put in the real app)
and the Tk thread drains them. Event kinds and payloads:

  busy(bool)  session_state(SessionState)  log((tag, text))
  device_check(Classified)  login_result(Classified)
  login_conflict({"login": Classified, "check": Classified|None})
  logout_result(Classified)  batch_started(int total)
  progress((done, total, TransactionResult))  batch_done(BatchSummary)
  error(str)  closed(None)
"""
from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Callable, Optional

from ..application.batch_runner import BatchRunner
from ..application.session_manager import Credentials, SessionManager, SessionState
from ..infrastructure.exceptions import SfcToolError
from ..integration.response_classifier import Outcome
from ..operations.definitions import Operation

log = logging.getLogger("sfc_tool.gui")


@dataclass(frozen=True)
class UiEvent:
    kind: str
    data: Any = None


class AppController:
    def __init__(self, session: SessionManager, runner: BatchRunner,
                 emit: Callable[[UiEvent], None], executor: Any = None) -> None:
        self._session, self._runner, self._emit = session, runner, emit
        self._exec = executor or ThreadPoolExecutor(max_workers=1, thread_name_prefix="sfc-worker")
        self._cancel = threading.Event()
        self._lock = threading.Lock()
        self._jobs = 0
        session.add_listener(lambda old, new: emit(UiEvent("session_state", new)))

    # -- observation -----------------------------------------------------------
    @property
    def state(self) -> SessionState:
        return self._session.state

    @property
    def device(self) -> Optional[str]:
        return self._session.device

    @property
    def busy(self) -> bool:
        return self._jobs > 0

    # -- job plumbing ----------------------------------------------------------
    def _submit(self, fn: Callable[[], None], *, force: bool = False) -> bool:
        with self._lock:
            if self._jobs > 0 and not force:
                return False                      # ignore double clicks
            self._jobs += 1
            first = self._jobs == 1
        if first:
            self._emit(UiEvent("busy", True))
        self._exec.submit(self._run_job, fn)
        return True

    def _run_job(self, fn: Callable[[], None]) -> None:
        try:
            fn()
        except SfcToolError as exc:               # messages are already user-safe
            self._emit(UiEvent("error", str(exc)))
        except Exception as exc:                  # a bug: log it, tell the user, never crash the app
            log.exception("gui_job_failed")
            self._emit(UiEvent("error", "Unexpected error (%s). See the log file." % type(exc).__name__))
        finally:
            with self._lock:
                self._jobs -= 1
                idle = self._jobs == 0
            if idle:
                self._emit(UiEvent("busy", False))

    def _log(self, tag: str, text: str) -> None:
        self._emit(UiEvent("log", (tag, text)))

    # -- actions (called from the Tk thread; return immediately) ---------------
    def check_device(self, creds: Optional[Credentials]) -> bool:
        def job() -> None:
            self._emit(UiEvent("device_check", self._session.check_device(creds)))
        return self._submit(job)

    def login(self, creds: Credentials) -> bool:
        def job() -> None:
            res = self._session.login(creds)
            self._emit(UiEvent("login_result", res))
            if res.outcome == Outcome.ALREADY_LOGGED_IN and self._session.has_pending_conflict:
                try:
                    chk = self._session.check_device(creds)
                except SfcToolError:
                    chk = None
                self._emit(UiEvent("login_conflict", {"login": res, "check": chk}))
        return self._submit(job)

    def resolve_conflict(self, confirmed: bool) -> None:
        """Called after the user answers the 'Login Twice' dialog."""
        if not confirmed:
            self._session.cancel_pending()
            self._log("info", "Conflict left untouched: the existing session was NOT logged out.")
            return

        def job() -> None:
            res = self._session.recover_already_logged_in(confirmed=True)
            self._emit(UiEvent("login_result", res))
        self._submit(job, force=True)

    def logout(self) -> bool:
        def job() -> None:
            self._emit(UiEvent("logout_result", self._session.logout()))
        return self._submit(job)

    def run_batch(self, op: Operation, params: dict, isns: list) -> bool:
        def job() -> None:
            self._cancel.clear()
            self._emit(UiEvent("batch_started", len(isns)))
            summary = self._runner.run(
                op, params, isns, cancel=self._cancel,
                on_progress=lambda d, t, r: self._emit(UiEvent("progress", (d, t, r))))
            self._emit(UiEvent("batch_done", summary))
        return self._submit(job)

    def cancel_batch(self) -> None:
        self._cancel.set()

    def shutdown(self) -> None:
        """Queue a best-effort logout + wipe after any running job, then signal 'closed'."""
        self._cancel.set()

        def job() -> None:
            try:
                out = self._session.shutdown()
                if out is not None:
                    self._log("info", "Logout on exit: %s" % out.outcome.value)
            finally:
                self._emit(UiEvent("closed"))
        self._submit(job, force=True)

    def dispose(self) -> None:
        try:
            self._exec.shutdown(wait=False)
        except Exception:
            pass
