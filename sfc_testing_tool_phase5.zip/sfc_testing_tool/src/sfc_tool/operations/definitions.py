"""Operation definitions (formerly the dicts in notebook cell 2).

`params` is the exact order sent on the wire (programId/programPassword are
injected first by the SessionManager). Defaults match the original tool, except
`error` (now empty) and `device` (the GUI fills it from the logged-in session).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping


@dataclass(frozen=True)
class Operation:
    key: str
    label: str
    method: str
    params: tuple
    defaults: Mapping[str, str] = field(default_factory=dict)
    required: tuple = ("device", "TSP", "status")   # must be non-empty (ISN is per item)


_BASE = ("ISN", "error", "device", "TSP", "data", "status", "CPKFlag")
# `error` is EMPTY by default (verified live): fill it only to report an error value.
_BASE_DEFAULTS = {"ISN": "", "error": "", "device": "", "TSP": "SFIS",
                  "data": "TEST", "status": "8", "CPKFlag": ""}

OPERATIONS: dict[str, Operation] = {
    "WTSP_RESULT": Operation(
        key="WTSP_RESULT", label="WTSP_RESULT (Bypass Single / Batch)",
        method="WTSP_RESULT", params=_BASE, defaults=dict(_BASE_DEFAULTS)),
    "WTSP_RESULT_MASSDATA": Operation(
        key="WTSP_RESULT_MASSDATA", label="WTSP_RESULT_MASSDATA (Extended Logs)",
        method="WTSP_RESULT_MASSDATA",
        params=_BASE + ("aoiloc", "data2", "data3", "data4", "data5",
                                     "data6", "data7", "data8"),
        defaults=dict(_BASE_DEFAULTS, aoiloc="TEST_LOC", data2="", data3="", data4="",
                      data5="", data6="", data7="", data8="")),
}


def get_operation(key: str) -> Operation:
    try:
        return OPERATIONS[key]
    except KeyError:
        raise KeyError("Unknown operation: %s" % key)
