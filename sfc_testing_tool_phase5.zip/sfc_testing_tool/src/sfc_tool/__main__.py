from .presentation.app import main

raise SystemExit(main())
