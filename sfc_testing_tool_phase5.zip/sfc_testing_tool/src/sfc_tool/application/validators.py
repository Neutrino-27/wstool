"""Local input validation. The SERVER decides what a valid ISN is: only
structural problems are checked here (no invented length/format rules)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Mapping

from ..infrastructure.exceptions import ValidationError
from ..operations.definitions import Operation

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


@dataclass
class IsnList:
    isns: list = field(default_factory=list)
    duplicates: list = field(default_factory=list)       # repeated values (dropped)
    invalid: list = field(default_factory=list)          # (line_no, raw, reason)


def parse_isn_list(text: str, *, allow_duplicates: bool = False) -> IsnList:
    out, seen = IsnList(), set()
    for n, raw in enumerate((text or "").splitlines(), start=1):
        isn = raw.strip()
        if not isn:
            continue
        if re.search(r"\s", isn):
            out.invalid.append((n, raw, "contains whitespace"))
        elif _CONTROL.search(isn):
            out.invalid.append((n, raw, "contains control characters"))
        elif isn in seen and not allow_duplicates:
            out.duplicates.append(isn)
        else:
            seen.add(isn)
            out.isns.append(isn)
    return out


def collect_isns(single: str, batch_text: str, *, allow_duplicates: bool = False) -> IsnList:
    """Batch text wins when present (same rule as the original tool); else the single ISN."""
    if (batch_text or "").strip():
        return parse_isn_list(batch_text, allow_duplicates=allow_duplicates)
    return parse_isn_list(single, allow_duplicates=allow_duplicates)


def build_params(op: Operation, base: Mapping[str, object], isn: str) -> list[tuple[str, str]]:
    """Validate `base` and return the ordered wire parameters for one ISN."""
    unknown = sorted(set(base) - set(op.params))
    if unknown:
        raise ValidationError("Unknown parameter(s) for %s: %s" % (op.method, ", ".join(unknown)))
    values = {k: str(base.get(k, op.defaults.get(k, ""))) for k in op.params}
    missing = [k for k in op.required if not values[k].strip()]
    if missing:
        raise ValidationError("Required parameter(s) empty: %s" % ", ".join(missing))
    if not isn or not isn.strip():
        raise ValidationError("ISN is required.")
    values["ISN"] = isn
    return [(k, values[k]) for k in op.params]
