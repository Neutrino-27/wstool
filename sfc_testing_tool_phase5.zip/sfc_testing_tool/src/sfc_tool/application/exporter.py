"""CSV export of batch results. Contains no credentials by construction."""
from __future__ import annotations

import csv
from typing import Iterable

COLUMNS = ["started_at", "operation", "isn", "status", "category", "outcome",
           "server_message", "duration_ms", "uncertain"]
_FORMULA_START = ("=", "+", "-", "@", "\t", "\r")


def _safe(value: object) -> str:
    """Neutralize spreadsheet formula injection (server text/ISNs are untrusted)."""
    text = "" if value is None else str(value).replace("\r", " ").replace("\n", " ")
    return "'" + text if text.startswith(_FORMULA_START) else text


def export_results_csv(results: Iterable, path: str) -> int:
    n = 0
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:   # BOM: Excel reads UTF-8
        w = csv.writer(fh)
        w.writerow(COLUMNS)
        for r in results:
            w.writerow([_safe(x) for x in (
                r.started_at, r.operation, r.isn, r.status.value, r.category.value,
                r.outcome, r.message, r.duration_ms, "YES" if r.uncertain else "")])
            n += 1
    return n
