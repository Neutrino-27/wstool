"""Sequential batch execution with per-ISN results, cancellation and abort rules.

A rejected ISN never stops the batch. The batch DOES stop (remaining ISNs are
reported SKIPPED, not silently dropped) when continuing is pointless or unsafe:
  * session lost/not authenticated, TLS failure, or an internal error: at once;
  * N consecutive connection failures / read timeouts (default 3).
Sequential on purpose: server concurrency behaviour is unverified.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Iterable, Mapping, Optional

from ..infrastructure.exceptions import DeviceMismatchError, NotAuthenticatedError, ValidationError
from ..operations.definitions import Operation
from .transaction_service import Category, Status, TransactionResult, TransactionService
from .validators import build_params

log = logging.getLogger("sfc_tool.batch")

_ABORT_NOW = {Category.SESSION, Category.TLS, Category.INTERNAL}
_BREAKER = {Category.CONNECTION, Category.TIMEOUT}


@dataclass
class BatchSummary:
    operation: str
    device: str
    started_at: str
    results: list = field(default_factory=list)
    duration_s: float = 0.0
    cancelled: bool = False
    aborted_reason: Optional[str] = None

    @property
    def total(self) -> int:
        return len(self.results)

    def counts_by_status(self) -> dict:
        out: dict = {}
        for r in self.results:
            out[r.status.value] = out.get(r.status.value, 0) + 1
        return out

    def counts_by_category(self) -> dict:
        out: dict = {}
        for r in self.results:
            if r.category != Category.NONE:
                out[r.category.value] = out.get(r.category.value, 0) + 1
        return out

    @property
    def needs_review(self) -> list:
        return [r for r in self.results if r.uncertain]

    @property
    def all_accepted(self) -> bool:
        return bool(self.results) and all(r.ok for r in self.results)


ProgressFn = Callable[[int, int, TransactionResult], None]


class BatchRunner:
    def __init__(self, service: TransactionService, *, max_consecutive_transport_errors: int = 3) -> None:
        self._svc = service
        self._max_transport = max_consecutive_transport_errors

    def run(self, op: Operation, base_params: Mapping[str, object], isns: Iterable[str], *,
            cancel: Optional[threading.Event] = None,
            on_progress: Optional[ProgressFn] = None) -> BatchSummary:
        isns = list(isns)
        if not isns:
            raise ValidationError("No ISNs to process.")
        build_params(op, base_params, isns[0])          # pre-flight: nothing is sent if invalid
        session_device = self._svc.session.device
        if session_device is None:
            raise NotAuthenticatedError("Not authenticated.")
        if str(base_params.get("device", "")) != session_device:
            raise DeviceMismatchError("Batch device differs from the logged-in device; log in on it first.")

        summary = BatchSummary(op.method, session_device, datetime.now().isoformat(timespec="seconds"))
        t0 = time.perf_counter()
        log.info("batch_start", extra={"fields": {"operation": op.method, "device": session_device, "total": len(isns)}})
        consecutive = 0
        stop_reason: Optional[str] = None
        stop_category = Category.ABORTED

        for i, isn in enumerate(isns):
            if cancel is not None and cancel.is_set():
                summary.cancelled, stop_reason, stop_category = True, "Cancelled by user", Category.CANCELLED
                break
            res = self._svc.execute_one(op, base_params, isn)
            summary.results.append(res)
            self._notify(on_progress, len(summary.results), len(isns), res)
            consecutive = consecutive + 1 if res.category in _BREAKER else 0
            if res.category in _ABORT_NOW:
                stop_reason = "Aborted: %s" % res.category.value
            elif consecutive >= self._max_transport:
                stop_reason = "Aborted: %d consecutive %s failures" % (consecutive, res.category.value)
            if stop_reason:
                break

        if stop_reason:
            summary.aborted_reason = None if summary.cancelled else stop_reason
            started = datetime.now().isoformat(timespec="seconds")
            for isn in isns[len(summary.results):]:
                skipped = TransactionResult(op.method, isn, Status.SKIPPED, stop_category,
                                            stop_reason, started_at=started)
                summary.results.append(skipped)
                self._notify(on_progress, len(summary.results), len(isns), skipped)

        summary.duration_s = round(time.perf_counter() - t0, 3)
        log.info("batch_end", extra={"fields": {
            "operation": op.method, "device": session_device, "duration_s": summary.duration_s,
            "by_status": summary.counts_by_status(), "by_category": summary.counts_by_category(),
            "cancelled": summary.cancelled, "aborted": summary.aborted_reason}})
        return summary

    @staticmethod
    def _notify(fn: Optional[ProgressFn], done: int, total: int, res: TransactionResult) -> None:
        if fn is None:
            return
        try:
            fn(done, total, res)
        except Exception:
            log.exception("progress_callback_failed")
